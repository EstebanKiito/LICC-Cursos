# Clase 16 — Responsive Design Demo

Demo interactivo de los conceptos de responsive design para IIC2182 Clase 16.

## Cómo correr

```bash
pnpm install
pnpm dev
```

Luego abrir http://localhost:3016

## Conceptos cubiertos

Cada página del demo es una sección autónoma:

| Ruta | Concepto |
|------|----------|
| `/breakpoints` | Tailwind sm/md/lg/xl con indicador en vivo |
| `/mobile-first-css` | min-width vs max-width comparados |
| `/fluid` | clamp() para tipografía y spacing fluidos |
| `/container-queries` | Mismo componente reaccionando a su contenedor |
| `/responsive-images` | srcset, picture, loading=lazy |
| `/layout-patterns` | Los 4 patrones de Wroblewski |
| `/touch-targets` | 44×44 px y por qué hover no existe en touch |
| `/hide-show` | Qué se puede esconder en mobile y qué nunca |
| `/preferences` | prefers-color-scheme y prefers-reduced-motion |
| `/dispersion` | El antipatrón de NN/g — dispersed vs condensed |

## Cómo demostrarlo en clase

1. Abrir DevTools y activar el modo responsive del navegador.
2. Navegar las secciones cambiando el ancho del viewport.
3. La insignia abajo a la derecha muestra qué breakpoint está activo en cada momento.
4. Para `/preferences`, cambiar el modo claro/oscuro del SO o activar &quot;Reduce motion&quot; en accesibilidad.

## Stack

- Next.js 15 (App Router)
- React 19
- Tailwind CSS 3
- @tailwindcss/container-queries plugin
