'use client'

import { useState } from 'react'
import PageHeader from '@/components/PageHeader'

const PALETTE = {
  blue: 'bg-blue-300 dark:bg-blue-800 text-blue-900 dark:text-blue-100',
  emerald: 'bg-emerald-300 dark:bg-emerald-800 text-emerald-900 dark:text-emerald-100',
  purple: 'bg-purple-300 dark:bg-purple-800 text-purple-900 dark:text-purple-100',
  amber: 'bg-amber-300 dark:bg-amber-800 text-amber-900 dark:text-amber-100',
} as const

type Color = keyof typeof PALETTE

function Cell({ label, color, className = '' }: { label: string; color: Color; className?: string }) {
  return (
    <div
      className={`rounded flex items-center justify-center text-[11px] font-mono font-bold ${PALETTE[color]} ${className}`}
    >
      {label}
    </div>
  )
}

/* Tailwind container-query breakpoints used here:
   @sm  = 384px  (24rem)
   @lg  = 512px  (32rem)
   We treat <384 as "small", 384-511 as "medium", ≥512 as "large".
*/

function PatternStage({
  width,
  setWidth,
  color,
  children,
}: {
  width: number
  setWidth: (n: number) => void
  color: Color
  children: React.ReactNode
}) {
  const sizeLabel = width < 384 ? 'small' : width < 512 ? 'medium' : 'large'
  const accent =
    color === 'blue'
      ? 'bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300'
      : color === 'emerald'
        ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300'
        : color === 'purple'
          ? 'bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-300'
          : 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300'

  return (
    <div>
      <div className="mb-3 rounded-lg border border-[var(--border)] bg-[var(--card-bg)] p-3">
        <div className="flex items-center gap-3 flex-wrap">
          <label className="text-sm font-bold whitespace-nowrap">Ancho del contenedor:</label>
          <input
            type="range"
            min={200}
            max={800}
            value={width}
            onChange={(e) => setWidth(Number(e.target.value))}
            className="flex-1 min-w-[200px]"
          />
          <span className={`px-3 py-1 rounded font-mono font-bold text-sm tabular-nums w-20 text-center ${accent}`}>
            {width}px
          </span>
        </div>
        <div className="mt-2 flex items-center gap-2 text-xs font-mono">
          <span className={`px-2 py-0.5 rounded ${accent}`}>{sizeLabel}</span>
          <span className="opacity-60">umbrales: @sm 384px · @lg 512px</span>
        </div>
      </div>

      <div
        className="rounded-lg border-2 border-dashed border-[var(--border)] p-3 transition-[width] duration-100"
        style={{ width: `${width}px`, maxWidth: '100%' }}
      >
        {children}
      </div>
    </div>
  )
}

/* ─────────────────────────  Mostly Fluid  ───────────────────────── */
function MostlyFluid() {
  return (
    <div className="@container">
      <div className="grid gap-1 mx-auto @lg:max-w-[80%]">
        <Cell label="header" color="blue" className="h-6" />
        <div className="grid grid-cols-1 @sm:grid-cols-3 gap-1">
          <Cell label="A" color="blue" className="h-16" />
          <Cell label="B" color="blue" className="h-16" />
          <Cell label="C" color="blue" className="h-16" />
        </div>
        <Cell label="footer" color="blue" className="h-6" />
      </div>
    </div>
  )
}
const mostlyFluidSrc = `<div className="@container">
  <div className="grid gap-1 mx-auto @lg:max-w-[80%]">
    <Cell label="header" />
    {/* 1 col en small → 3 cols fluidas a partir de @sm  */}
    <div className="grid grid-cols-1 @sm:grid-cols-3 gap-1">
      <Cell label="A" /><Cell label="B" /><Cell label="C" />
    </div>
    <Cell label="footer" />
  </div>
</div>`

/* ─────────────────────────  Column Drop  ───────────────────────── */
function ColumnDrop() {
  return (
    <div className="@container">
      <div className="grid grid-cols-1 @sm:grid-cols-2 @lg:grid-cols-3 gap-1">
        <Cell label="A" color="emerald" className="h-20" />
        <Cell label="B" color="emerald" className="h-20" />
        <Cell label="C" color="emerald" className="h-20" />
      </div>
    </div>
  )
}
const columnDropSrc = `<div className="@container">
  {/* 1 → 2 → 3 columnas. Las celdas "caen" una a una. */}
  <div className="grid grid-cols-1 @sm:grid-cols-2 @lg:grid-cols-3 gap-1">
    <Cell label="A" /><Cell label="B" /><Cell label="C" />
  </div>
</div>`

/* ─────────────────────────  Layout Shifter  ───────────────────────── */
function LayoutShifter() {
  return (
    <div className="@container">
      <div className="grid gap-1 grid-cols-1 @sm:grid-cols-2 @lg:grid-cols-3">
        <div
          className={`rounded flex items-center justify-center text-[11px] font-mono font-bold ${PALETTE.purple}
                      h-16 @sm:h-20 @lg:h-32 @lg:row-span-2`}
        >
          Hero
        </div>
        <div
          className={`rounded flex items-center justify-center text-[11px] font-mono font-bold ${PALETTE.purple}
                      h-6 @sm:h-20 @lg:col-span-2 @lg:h-10`}
        >
          Title
        </div>
        <Cell label="A" color="purple" className="h-10 @sm:h-12 @lg:h-20 @lg:col-start-2" />
        <Cell label="B" color="purple" className="h-10 @sm:h-12 @lg:h-20" />
      </div>
    </div>
  )
}
const layoutShifterSrc = `<div className="@container">
  <div className="grid gap-1 grid-cols-1 @sm:grid-cols-2 @lg:grid-cols-3">
    {/*  En @lg el Hero ocupa la columna izquierda completa  */}
    <Cell label="Hero"  className="@lg:row-span-2 @lg:h-32" />
    {/*  Title pasa a ocupar las 2 columnas de la derecha   */}
    <Cell label="Title" className="@lg:col-span-2" />
    {/*  A y B se reubican debajo de Title (col 2 y 3)      */}
    <Cell label="A"     className="@lg:col-start-2" />
    <Cell label="B" />
  </div>
</div>`

/* ─────────────────────────  Off-Canvas  ───────────────────────── */
function OffCanvas() {
  return (
    <div className="@container">
      <div className="grid gap-1">
        <div className="flex gap-1">
          <div
            className={`rounded flex items-center justify-center text-[11px] font-mono font-bold ${PALETTE.amber}
                        h-6 w-6 @lg:hidden`}
          >
            ☰
          </div>
          <Cell label="header" color="amber" className="h-6 flex-1" />
        </div>
        <div className="grid gap-1 grid-cols-1 @lg:grid-cols-[80px_1fr]">
          <Cell label="nav" color="amber" className="h-32 hidden @lg:flex" />
          <Cell label="main" color="amber" className="h-32" />
        </div>
      </div>
    </div>
  )
}
const offCanvasSrc = `<div className="@container">
  <div className="grid gap-1">
    {/*  El botón ☰ desaparece a partir de @lg                 */}
    <div className="flex gap-1">
      <button className="@lg:hidden">☰</button>
      <Cell label="header" />
    </div>
    {/*  La nav está oculta hasta @lg, donde aparece a la izq.  */}
    <div className="grid gap-1 grid-cols-1 @lg:grid-cols-[80px_1fr]">
      <Cell label="nav" className="hidden @lg:flex" />
      <Cell label="main" />
    </div>
  </div>
</div>`

/* ─────────────────────────  Page  ───────────────────────── */
export default function LayoutPatternsPage() {
  const [w1, setW1] = useState(300)
  const [w2, setW2] = useState(300)
  const [w3, setW3] = useState(300)
  const [w4, setW4] = useState(300)

  return (
    <div>
      <PageHeader
        title="Patrones de layout responsive"
        subtitle="Los 4 patrones canónicos de Luke Wroblewski. Cada demo es código real con container queries — arrastra el slider y mira cómo se reorganiza."
        hint="Los breakpoints @sm (384px) y @lg (512px) son los umbrales reales. Cruza el slider por encima/abajo para ver el flip."
      />

      <section className="space-y-12">
        <Pattern
          number={1}
          title="Mostly Fluid"
          color="blue"
          desc="El layout es elástico — las columnas existen siempre y se estiran fluidamente. Solo en el viewport más chico colapsa todo a una columna. La estructura cambia poco; lo que cambia es el ancho."
          rule="Estructura estable + columnas fluidas. Margen aparece en viewports muy grandes."
          source={mostlyFluidSrc}
        >
          <PatternStage width={w1} setWidth={setW1} color="blue">
            <MostlyFluid />
          </PatternStage>
        </Pattern>

        <Pattern
          number={2}
          title="Column Drop"
          color="emerald"
          desc="Múltiples columnas en desktop. A medida que el viewport se achica, las columnas se van 'cayendo' UNA A UNA debajo de la línea — no todas a la vez."
          rule="Las columnas se apilan progresivamente, una por breakpoint."
          source={columnDropSrc}
        >
          <PatternStage width={w2} setWidth={setW2} color="emerald">
            <ColumnDrop />
          </PatternStage>
        </Pattern>

        <Pattern
          number={3}
          title="Layout Shifter"
          color="purple"
          desc="La estructura del layout cambia DRÁSTICAMENTE entre breakpoints. No es solo apilar — los elementos se reubican, cambian de tamaño relativo, e incluso cambian de jerarquía visual."
          rule="Cada breakpoint tiene un layout estructuralmente distinto."
          source={layoutShifterSrc}
        >
          <PatternStage width={w3} setWidth={setW3} color="purple">
            <LayoutShifter />
          </PatternStage>
        </Pattern>

        <Pattern
          number={4}
          title="Off-Canvas"
          color="amber"
          desc="El contenido principal mantiene su layout. Lo que cambia es UN panel secundario (nav, sidebar) que vive fuera del viewport en mobile y se muestra persistente en desktop. Aparece por gesto en mobile."
          rule="Layout principal estable; un panel lateral aparece/desaparece."
          source={offCanvasSrc}
        >
          <PatternStage width={w4} setWidth={setW4} color="amber">
            <OffCanvas />
          </PatternStage>
        </Pattern>
      </section>

      <section className="mt-12 p-4 rounded-lg border border-[var(--border)] bg-[var(--card-bg)]">
        <h2 className="font-bold mb-3">¿Cómo distinguirlos en una palabra?</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 text-sm">
          <div className="p-3 rounded bg-blue-50 dark:bg-blue-950/30">
            <div className="font-bold text-blue-700 dark:text-blue-400">Mostly Fluid</div>
            <div className="text-xs opacity-80 mt-1">Estira</div>
          </div>
          <div className="p-3 rounded bg-emerald-50 dark:bg-emerald-950/30">
            <div className="font-bold text-emerald-700 dark:text-emerald-400">Column Drop</div>
            <div className="text-xs opacity-80 mt-1">Apila progresivamente</div>
          </div>
          <div className="p-3 rounded bg-purple-50 dark:bg-purple-950/30">
            <div className="font-bold text-purple-700 dark:text-purple-400">Layout Shifter</div>
            <div className="text-xs opacity-80 mt-1">Reorganiza</div>
          </div>
          <div className="p-3 rounded bg-amber-50 dark:bg-amber-950/30">
            <div className="font-bold text-amber-700 dark:text-amber-400">Off-Canvas</div>
            <div className="text-xs opacity-80 mt-1">Esconde panel lateral</div>
          </div>
        </div>
      </section>
    </div>
  )
}

function Pattern({
  number,
  title,
  color,
  desc,
  rule,
  source,
  children,
}: {
  number: number
  title: string
  color: Color
  desc: string
  rule: string
  source: string
  children: React.ReactNode
}) {
  const accent: Record<Color, string> = {
    blue: 'text-blue-700 dark:text-blue-400',
    emerald: 'text-emerald-700 dark:text-emerald-400',
    purple: 'text-purple-700 dark:text-purple-400',
    amber: 'text-amber-700 dark:text-amber-400',
  }
  const bg: Record<Color, string> = {
    blue: 'bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-900',
    emerald: 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-900',
    purple: 'bg-purple-50 dark:bg-purple-950/30 border-purple-200 dark:border-purple-900',
    amber: 'bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900',
  }
  return (
    <div className={`rounded-lg border-2 ${bg[color]} p-5`}>
      <div className="flex items-baseline gap-3 mb-2">
        <span className={`text-3xl font-black ${accent[color]}`}>#{number}</span>
        <h2 className={`font-bold text-lg ${accent[color]}`}>{title}</h2>
      </div>
      <p className="text-sm opacity-80 mb-2">{desc}</p>
      <div className="text-xs font-bold opacity-70 mb-4">→ {rule}</div>
      {children}
      <details className="mt-4 text-sm">
        <summary className="cursor-pointer font-bold opacity-80 hover:opacity-100">
          Ver código
        </summary>
        <pre className="text-xs bg-black/5 dark:bg-white/5 p-3 rounded mt-2 overflow-x-auto">
          <code>{source}</code>
        </pre>
      </details>
    </div>
  )
}
