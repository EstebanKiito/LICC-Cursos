'use client'

import { useState } from 'react'
import PageHeader from '../../components/PageHeader'

export default function TouchTargetsPage() {
  const [badHits, setBadHits] = useState(0)
  const [goodHits, setGoodHits] = useState(0)
  const [badMisses, setBadMisses] = useState(0)

  return (
    <div>
      <PageHeader
        title="Touch targets"
        subtitle="44×44 px (Apple HIG) o 48 dp (Material) son los mínimos para que un dedo acierte cómodamente. Pruébalo: si estás en mobile o táctil."
        hint="En desktop los botones pequeños se ven OK. Conecta tu teléfono al sitio (mismo wifi → IP local) e intenta ahí."
      />

      <section className="space-y-8">
        <div className="grid md:grid-cols-2 gap-4">
          <div className="rounded-lg border border-rose-300 bg-rose-50 dark:bg-rose-950/30 p-5">
            <div className="font-bold text-rose-700 dark:text-rose-400 mb-3">
              ✗ Targets muy chicos (24×24)
            </div>
            <div className="flex gap-1 flex-wrap">
              {Array.from({ length: 8 }).map((_, i) => (
                <button
                  key={i}
                  onClick={() => setBadHits((n) => n + 1)}
                  className="w-6 h-6 rounded bg-rose-600 text-white text-[10px] flex items-center justify-center"
                >
                  {i + 1}
                </button>
              ))}
            </div>
            <div
              className="mt-3 h-12 border-2 border-dashed border-rose-300 rounded flex items-center justify-center text-xs opacity-60"
              onClick={() => setBadMisses((n) => n + 1)}
            >
              Zona &quot;casi&quot; — el dedo cae acá fácilmente
            </div>
            <div className="text-xs mt-3">
              Aciertos: {badHits} · Erratas: {badMisses}
            </div>
          </div>

          <div className="rounded-lg border border-emerald-300 bg-emerald-50 dark:bg-emerald-950/30 p-5">
            <div className="font-bold text-emerald-700 dark:text-emerald-400 mb-3">
              ✓ Targets correctos (≥44×44)
            </div>
            <div className="flex gap-2 flex-wrap">
              {Array.from({ length: 4 }).map((_, i) => (
                <button
                  key={i}
                  onClick={() => setGoodHits((n) => n + 1)}
                  className="min-w-[44px] min-h-[44px] px-3 rounded bg-emerald-600 text-white text-sm flex items-center justify-center"
                >
                  Botón {i + 1}
                </button>
              ))}
            </div>
            <div className="mt-3 h-12 flex items-center text-xs opacity-60">
              Espacio amplio entre targets
            </div>
            <div className="text-xs mt-3">Aciertos: {goodHits}</div>
          </div>
        </div>

        <div className="rounded-lg border border-[var(--border)] bg-[var(--card-bg)] p-5">
          <h2 className="font-bold mb-3">Hover no existe en touch</h2>
          <p className="text-sm opacity-80 mb-4">
            Pasa el mouse sobre la tarjeta para ver el menú. Ahora hazlo con un dedo.
          </p>
          <div className="grid md:grid-cols-2 gap-4">
            <article className="group relative rounded border border-[var(--border)] p-4 bg-blue-50 dark:bg-blue-950/30">
              <h3 className="font-bold">Tarjeta con menú hover</h3>
              <p className="text-xs opacity-70 mt-1">Hovea para ver acciones.</p>
              <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                <button className="px-2 py-1 bg-white dark:bg-black rounded text-xs">Editar</button>
                <button className="px-2 py-1 bg-white dark:bg-black rounded text-xs">Borrar</button>
              </div>
            </article>

            <article className="rounded border border-[var(--border)] p-4 bg-emerald-50 dark:bg-emerald-950/30">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="font-bold">Tarjeta con menú visible</h3>
                  <p className="text-xs opacity-70 mt-1">Acciones siempre presentes.</p>
                </div>
                <button
                  className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded bg-white dark:bg-black"
                  aria-label="Más opciones"
                >
                  ⋯
                </button>
              </div>
            </article>
          </div>
          <p className="text-sm opacity-80 mt-4">
            La tarjeta de la izquierda esconde funcionalidad bajo hover — invisible en touch. La tarjeta derecha la muestra (o detrás de un botón explícito de 44×44).
          </p>
        </div>

        <div className="rounded-lg border border-[var(--border)] bg-[var(--card-bg)] p-5">
          <h2 className="font-bold mb-2">Tamaños de referencia</h2>
          <ul className="text-sm space-y-1 opacity-80">
            <li><strong>Apple HIG (iOS):</strong> 44×44 puntos mínimo</li>
            <li><strong>Material Design (Android):</strong> 48×48 dp mínimo</li>
            <li><strong>WCAG 2.2 AA:</strong> 24×24 px mínimo (con espaciado), 44×44 ideal</li>
            <li><strong>Espaciado entre targets:</strong> ≥ 8px para evitar misclicks</li>
          </ul>
        </div>
      </section>
    </div>
  )
}
