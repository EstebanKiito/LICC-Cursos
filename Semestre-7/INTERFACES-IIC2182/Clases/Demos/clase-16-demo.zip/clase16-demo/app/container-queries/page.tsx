import PageHeader from '@/components/PageHeader'
import MeasuredContainer from '@/components/MeasuredContainer'
import ResizableContainer from '@/components/ResizableContainer'

function ProductCard() {
  return (
    <article className="@container rounded-lg border border-[var(--border)] bg-[var(--card-bg)] overflow-hidden">
      <div className="@md:flex">
        <div className="@md:w-40 h-32 @md:h-auto bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-white text-3xl font-bold">
          ☕
        </div>
        <div className="p-3 @md:p-4 flex-1">
          <div className="text-[10px] @md:text-xs uppercase tracking-wider opacity-60">
            Café de origen
          </div>
          <h3 className="font-bold text-sm @md:text-lg mt-1">Etiopía Yirgacheffe</h3>
          <p className="text-xs opacity-70 mt-1 hidden @md:block">
            Notas a flores blancas, té negro y cítricos. Tueste medio.
          </p>
          <div className="mt-2 @md:mt-3 flex items-center gap-2">
            <span className="font-bold text-sm @md:text-base">$12.990</span>
            <button className="ml-auto px-2 py-1 @md:px-3 @md:py-1.5 bg-blue-600 text-white rounded text-xs @md:text-sm">
              Agregar
            </button>
          </div>
        </div>
      </div>
    </article>
  )
}

const productCardSource = `function ProductCard() {
  return (
    //  ↓ marca este elemento como un container
    <article className="@container ...">
      {/*  @md: aplica cuando el CONTENEDOR ≥ 28rem (448px)  */}
      <div className="@md:flex">
        <div className="@md:w-40 h-32 @md:h-auto ...">☕</div>
        <div className="p-3 @md:p-4 flex-1">
          <h3 className="text-sm @md:text-lg">Etiopía Yirgacheffe</h3>
          {/* La descripción solo aparece si hay espacio */}
          <p className="hidden @md:block">Notas a flores blancas...</p>
          <div className="flex items-center gap-2">
            <span className="text-sm @md:text-base">$12.990</span>
            <button className="px-2 py-1 @md:px-3 @md:py-1.5">
              Agregar
            </button>
          </div>
        </div>
      </div>
    </article>
  )
}`

export default function ContainerQueriesPage() {
  return (
    <div>
      <PageHeader
        title="Container queries"
        subtitle="El mismo componente <ProductCard /> renderizado en distintos contenedores. Reacciona al ANCHO de su contenedor, no al viewport."
        hint="Usa el slider del demo interactivo para ver el flip exacto en el breakpoint de 448px."
      />

      <section className="mb-10">
        <h2 className="font-bold mb-1">Demo interactivo — arrastra el slider</h2>
        <p className="text-sm opacity-70 mb-4">
          Este es el camino más claro para ver el efecto: cambia solo el ancho del contenedor y observa cuándo cruza el umbral de 448px.
        </p>
        <ResizableContainer initial={300}>
          <ProductCard />
        </ResizableContainer>
      </section>

      <section className="mb-10">
        <h2 className="font-bold mb-1">3 instancias, 3 contenedores distintos</h2>
        <p className="text-sm opacity-70 mb-4">
          Mismo código React, distinto contexto. Cada contenedor reporta su ancho real y si <code className="text-xs bg-black/10 dark:bg-white/10 px-1 rounded">@md</code> está activa.
        </p>

        <div className="grid lg:grid-cols-[200px_1fr_300px] gap-4">
          <MeasuredContainer label="Sidebar fijo">
            <ProductCard />
          </MeasuredContainer>

          <MeasuredContainer label="Main fluid">
            <ProductCard />
          </MeasuredContainer>

          <MeasuredContainer label="Aside fijo">
            <ProductCard />
          </MeasuredContainer>
        </div>

        <p className="text-xs opacity-60 mt-3">
          ↑ Estira la ventana horizontalmente y observa: el <strong>main</strong> cruza el umbral cuando el viewport crece, mientras que el sidebar y el aside (anchos fijos) nunca lo cruzan.
        </p>
      </section>

      <section className="mb-10">
        <h2 className="font-bold mb-3">El componente</h2>
        <div className="rounded-lg border border-[var(--border)] bg-[var(--card-bg)] overflow-hidden">
          <div className="px-4 py-2 border-b border-[var(--border)] bg-black/[.02] dark:bg-white/[.02] flex items-center gap-2">
            <span className="text-xs font-mono opacity-60">components/ProductCard.tsx</span>
          </div>
          <pre className="text-xs p-4 overflow-x-auto leading-relaxed">
            <code>{productCardSource}</code>
          </pre>
        </div>
      </section>

      <section className="grid md:grid-cols-2 gap-4">
        <div className="rounded-lg border border-[var(--border)] bg-[var(--card-bg)] p-4">
          <h2 className="font-bold mb-2 text-sm">CSS nativo equivalente</h2>
          <pre className="text-xs bg-black/5 dark:bg-white/5 p-3 rounded overflow-x-auto">
{`.card-wrapper {
  /* Marca el elemento como contenedor */
  container-type: inline-size;
}

/* Aplica cuando el CONTENEDOR (no el viewport) */
/* alcanza el ancho dado */
@container (min-width: 28rem) {
  .card-inner   { display: flex; }
  .card-image   { width: 10rem; }
  .card-desc    { display: block; }
}`}
          </pre>
        </div>

        <div className="rounded-lg border border-[var(--border)] bg-[var(--card-bg)] p-4">
          <h2 className="font-bold mb-2 text-sm">Por qué importa para design systems</h2>
          <p className="text-sm opacity-80">
            Un componente que solo conoce el viewport asume dónde vive. Container queries lo hacen <strong>independiente del contexto</strong>: la misma <code className="text-xs bg-black/10 dark:bg-white/10 px-1 rounded">&lt;ProductCard /&gt;</code> funciona en sidebar, grid central o full-width sin tocar el código.
          </p>
          <p className="text-xs opacity-60 mt-3">
            Disponible en todos los browsers modernos desde 2023.
          </p>
        </div>
      </section>
    </div>
  )
}
