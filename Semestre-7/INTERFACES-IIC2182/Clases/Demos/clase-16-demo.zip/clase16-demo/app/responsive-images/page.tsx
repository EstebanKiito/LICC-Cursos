import Image from 'next/image'
import PageHeader from '@/components/PageHeader'
import ResponsiveImageDemo from '@/components/ResponsiveImageDemo'

export default function ResponsiveImagesPage() {
  return (
    <div>
      <PageHeader
        title="Imágenes responsive"
        subtitle="srcset, <picture> y next/image: tres formas de servir la imagen correcta a cada contexto."
        hint="Arrastra el slider del primer demo. La imagen cambia físicamente entre 400w/800w/1600w según el ancho × DPR."
      />

      <section className="mb-10">
        <h2 className="font-bold mb-2">1. srcset — distintas resoluciones</h2>
        <p className="text-sm opacity-80 mb-3">
          El navegador elige la imagen más eficiente según el slot real, <code className="text-xs bg-black/10 dark:bg-white/10 px-1 rounded">sizes</code> y densidad de pantalla (retina). Cada archivo tiene un color y un texto distinto para que veas exactamente cuál se descargó.
        </p>
        <ResponsiveImageDemo />
        <pre className="text-xs bg-black/5 dark:bg-white/5 p-3 rounded mt-3 overflow-x-auto">
{`<img
  src="/img/hero-800.png"
  srcSet="/img/hero-400.png 400w,
          /img/hero-800.png 800w,
          /img/hero-1600.png 1600w"
  sizes="(min-width: 1024px) 800px,
         (min-width: 640px)  70vw,
         100vw"
  alt="..."
/>`}
        </pre>
        <div className="mt-3 text-xs opacity-70 space-y-1">
          <div><strong>Cómo lee el navegador:</strong> evalúa <code className="bg-black/10 dark:bg-white/10 px-1 rounded">sizes</code> de izquierda a derecha, encuentra el slot que aplica al viewport actual, multiplica por <code className="bg-black/10 dark:bg-white/10 px-1 rounded">window.devicePixelRatio</code>, y elige la entrada de <code className="bg-black/10 dark:bg-white/10 px-1 rounded">srcset</code> con el menor ancho que cubra ese cálculo.</div>
        </div>
      </section>

      <section className="mb-10">
        <h2 className="font-bold mb-2">2. &lt;picture&gt; — art direction</h2>
        <p className="text-sm opacity-80 mb-3">
          No es solo elegir tamaño: es elegir un <strong>recorte distinto</strong>. Útil cuando el formato vertical/horizontal cambia la composición. La versión móvil es cuadrada (sujeto cerrado); la versión desktop es panorámica (con contexto lateral).
        </p>
        <div className="rounded-lg border border-[var(--border)] bg-[var(--card-bg)] p-3">
          <picture>
            <source media="(min-width: 768px)" srcSet="/img/hero-wide.svg" />
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/img/hero-square.svg" alt="Hero responsive" className="w-full rounded" />
          </picture>
        </div>
        <pre className="text-xs bg-black/5 dark:bg-white/5 p-3 rounded mt-3 overflow-x-auto">
{`<picture>
  <source media="(min-width: 768px)" srcset="/img/hero-wide.svg" />
  <img src="/img/hero-square.svg" alt="..." />
</picture>`}
        </pre>
        <p className="text-xs opacity-70 mt-2">
          Cruza el viewport el umbral de 768px y la imagen cambia de cuadrada (rosa/púrpura) a ancha (azul). Es un recorte distinto, no solo un tamaño distinto.
        </p>
      </section>

      <section className="mb-10">
        <h2 className="font-bold mb-2">3. next/image — el wrapper de Next.js</h2>
        <p className="text-sm opacity-80 mb-3">
          Next.js incluye <code className="text-xs bg-black/10 dark:bg-white/10 px-1 rounded">&lt;Image&gt;</code>, que automatiza casi todo lo anterior y agrega optimizaciones del lado del servidor.
        </p>
        <div className="rounded-lg border border-[var(--border)] bg-[var(--card-bg)] p-3">
          <Image
            src="/img/hero-1600.png"
            alt="Demo next/image"
            width={1600}
            height={1000}
            sizes="(min-width: 1024px) 800px, (min-width: 640px) 70vw, 100vw"
            className="w-full h-auto rounded"
            priority={false}
          />
        </div>
        <pre className="text-xs bg-black/5 dark:bg-white/5 p-3 rounded mt-3 overflow-x-auto">
{`import Image from 'next/image'

<Image
  src="/img/hero-1600.png"
  alt="..."
  width={1600}
  height={1000}
  sizes="(min-width: 1024px) 800px,
         (min-width: 640px)  70vw,
         100vw"
/>`}
        </pre>

        <div className="grid sm:grid-cols-2 gap-3 mt-4">
          <div className="rounded p-3 border border-emerald-300 bg-emerald-50 dark:bg-emerald-950/30">
            <div className="font-bold text-sm text-emerald-700 dark:text-emerald-400 mb-1">Lo que te ahorra</div>
            <ul className="text-xs space-y-1 list-disc pl-4 opacity-80">
              <li><strong>srcset automático</strong> — genera múltiples tamaños desde la imagen original</li>
              <li><strong>Conversión a WebP/AVIF</strong> según el navegador</li>
              <li><strong>Lazy loading</strong> por defecto (off-screen)</li>
              <li><strong>Reserva del espacio</strong> usando <code className="bg-black/10 dark:bg-white/10 px-1 rounded">width × height</code> → previene CLS</li>
              <li><strong>Cache</strong> en el servidor de Next.js / CDN</li>
            </ul>
          </div>

          <div className="rounded p-3 border border-amber-300 bg-amber-50 dark:bg-amber-950/30">
            <div className="font-bold text-sm text-amber-700 dark:text-amber-400 mb-1">Lo que TÚ tienes que dar</div>
            <ul className="text-xs space-y-1 list-disc pl-4 opacity-80">
              <li><strong>width y height</strong> de la imagen original (para reservar espacio)</li>
              <li><strong>sizes</strong> — Next.js no lo adivina; describe cuánto espacio ocupará la imagen en el layout</li>
              <li><strong>priority</strong> en imágenes críticas (above-the-fold) para precargar y evitar lazy</li>
              <li><strong>alt</strong> — accesibilidad, igual que con <code className="bg-black/10 dark:bg-white/10 px-1 rounded">&lt;img&gt;</code></li>
            </ul>
          </div>
        </div>

        <div className="mt-4 rounded p-3 border border-[var(--border)] bg-[var(--card-bg)]">
          <div className="font-bold text-sm mb-1">Inspecciona en DevTools</div>
          <p className="text-xs opacity-80">
            Abre la pestaña Network y filtra por <code className="bg-black/10 dark:bg-white/10 px-1 rounded">_next/image</code>. Vas a ver requests como <code className="bg-black/10 dark:bg-white/10 px-1 rounded">/_next/image?url=...&w=640&q=75</code> — Next.js sirve la imagen procesada al tamaño exacto que el navegador pidió.
          </p>
        </div>
      </section>

      <section className="rounded-lg border border-[var(--border)] bg-[var(--card-bg)] p-4">
        <h2 className="font-bold mb-2">¿Cuál usar?</h2>
        <ul className="text-sm space-y-2 opacity-80">
          <li><strong>srcset:</strong> mismo recorte, distinto tamaño. Tu primera herramienta para hero/cover images.</li>
          <li><strong>&lt;picture&gt;:</strong> distinto recorte por viewport (art direction) — mobile vs desktop con composición distinta.</li>
          <li><strong>next/image:</strong> dentro de Next.js, casi siempre. Te ahorra el srcset manual y agrega WebP/AVIF.</li>
          <li><strong>loading=&quot;lazy&quot;:</strong> con <code className="text-xs bg-black/10 dark:bg-white/10 px-1 rounded">&lt;img&gt;</code>, defiere imágenes off-screen. Con next/image ya viene activo por defecto.</li>
        </ul>
      </section>
    </div>
  )
}
