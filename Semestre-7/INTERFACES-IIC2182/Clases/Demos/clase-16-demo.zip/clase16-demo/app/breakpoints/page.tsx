import PageHeader from '@/components/PageHeader'

export default function BreakpointsPage() {
  return (
    <div>
      <PageHeader
        title="Breakpoints"
        subtitle="Tailwind sigue la convención mobile-first: las clases sin prefijo aplican a TODO, los prefijos sm: md: lg: xl: aplican a partir de ese ancho."
        hint="Cambia el ancho del navegador y observa la insignia inferior derecha."
      />

      <section className="space-y-6">
        <Demo
          title="1. Tipografía que cambia por breakpoint"
          code={`<h2 class="text-base sm:text-lg md:text-xl lg:text-2xl xl:text-3xl">`}
        >
          <h2 className="text-base sm:text-lg md:text-xl lg:text-2xl xl:text-3xl font-bold">
            Cambia conmigo
          </h2>
          <p className="text-xs opacity-60 mt-2">
            base → sm → md → lg → xl
          </p>
        </Demo>

        <Demo
          title="2. Grid que cambia número de columnas"
          code={`<div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">`}
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="bg-blue-100 dark:bg-blue-950 rounded p-3 text-center text-sm">
                Item {i + 1}
              </div>
            ))}
          </div>
          <p className="text-xs opacity-60 mt-2">
            1 col en mobile → 2 en sm → 3 en md → 4 en lg
          </p>
        </Demo>

        <Demo
          title="3. Cambio de dirección flex"
          code={`<div class="flex flex-col md:flex-row">`}
        >
          <div className="flex flex-col md:flex-row gap-2">
            <div className="flex-1 bg-emerald-100 dark:bg-emerald-950 rounded p-3 text-sm">A</div>
            <div className="flex-1 bg-emerald-100 dark:bg-emerald-950 rounded p-3 text-sm">B</div>
            <div className="flex-1 bg-emerald-100 dark:bg-emerald-950 rounded p-3 text-sm">C</div>
          </div>
          <p className="text-xs opacity-60 mt-2">
            Apilados en mobile, en fila desde md.
          </p>
        </Demo>

        <Demo
          title="4. Mostrar / ocultar por viewport"
          code={`<div class="hidden md:block">/* solo desde md */</div>`}
        >
          <div className="space-y-2">
            <div className="block md:hidden bg-rose-100 dark:bg-rose-950 rounded p-3 text-sm">
              Solo visible en mobile (&lt; md)
            </div>
            <div className="hidden md:block bg-purple-100 dark:bg-purple-950 rounded p-3 text-sm">
              Solo visible en desktop (≥ md)
            </div>
          </div>
        </Demo>
      </section>

      <section className="mt-10 p-4 rounded-lg border border-amber-300 bg-amber-50 dark:bg-amber-950/30">
        <h2 className="font-bold text-sm mb-2">⚠ Anti-patrón</h2>
        <p className="text-sm">
          No hagas breakpoints por dispositivo (<code className="text-xs bg-black/10 dark:bg-white/10 px-1 rounded">@media (max-width: 414px)</code> para iPhone).
          Define breakpoints donde tu <strong>contenido</strong> se rompe — esos siguen funcionando aunque salga un nuevo iPhone mañana.
        </p>
      </section>
    </div>
  )
}

function Demo({ title, code, children }: { title: string; code: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-[var(--border)] bg-[var(--card-bg)] overflow-hidden">
      <div className="px-4 py-2 border-b border-[var(--border)] bg-black/[.02] dark:bg-white/[.02]">
        <div className="text-sm font-semibold">{title}</div>
        <code className="text-xs opacity-60 block mt-1 font-mono">{code}</code>
      </div>
      <div className="p-4">{children}</div>
    </div>
  )
}
