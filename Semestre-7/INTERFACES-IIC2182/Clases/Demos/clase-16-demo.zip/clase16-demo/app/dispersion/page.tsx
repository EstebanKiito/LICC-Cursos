import PageHeader from '@/components/PageHeader'

export default function DispersionPage() {
  return (
    <div>
      <PageHeader
        title="Content dispersion"
        subtitle="El antipatrón documentado por NN/g (2024): páginas responsive cuyo render desktop queda inflado, con elementos enormes y mucho whitespace, obligando al usuario a scrollear para ver lo que cabría en una sola pantalla bien diseñada."
        hint="Scrollea dentro del marco de la derecha para recorrer el ejemplo completo. La página tiene ~7000px de alto en desktop."
      />

      <section className="grid lg:grid-cols-[1fr_2fr] gap-6 mb-10">
        <div className="space-y-4">
          <div className="rounded-lg border border-rose-300 bg-rose-50 dark:bg-rose-950/30 p-4">
            <h2 className="font-bold text-sm mb-2 text-rose-700 dark:text-rose-400">
              ✗ Síntomas
            </h2>
            <ul className="text-sm space-y-1 list-disc pl-5 opacity-80">
              <li>Hero gigante que ocupa toda la primera pantalla.</li>
              <li>Cada bloque de contenido aislado en su propio viewport.</li>
              <li>Whitespace exagerado entre secciones.</li>
              <li>Información relacionada (precio + reviews + CTA) separada por scroll.</li>
            </ul>
          </div>

          <div className="rounded-lg border border-emerald-300 bg-emerald-50 dark:bg-emerald-950/30 p-4">
            <h2 className="font-bold text-sm mb-2 text-emerald-700 dark:text-emerald-400">
              ✓ Antídoto
            </h2>
            <ul className="text-sm space-y-1 list-disc pl-5 opacity-80">
              <li>Probar el rendering desktop, no asumir.</li>
              <li>Cada imagen debe ganar su lugar.</li>
              <li>Agrupar info que el usuario consume en simultáneo.</li>
              <li>Re-diseñar el layout para desktop, no estirar el de mobile.</li>
            </ul>
          </div>

          <div className="rounded-lg border border-[var(--border)] bg-[var(--card-bg)] p-4">
            <h2 className="font-bold text-sm mb-2">Los 3 culpables</h2>
            <ol className="text-sm space-y-1 list-decimal pl-5 opacity-80">
              <li>Mobile-first mal aplicado (escalar en vez de rediseñar).</li>
              <li>Minimalismo excesivo (clean = vacío).</li>
              <li>Imágenes hero del tamaño del viewport.</li>
            </ol>
          </div>
        </div>

        <div>
          <div className="text-xs opacity-60 mb-2">
            Ejemplo real — página dispersed (scrollea adentro):
          </div>
          <div className="rounded-lg border-2 border-rose-300 overflow-y-auto bg-rose-50 dark:bg-rose-950/20 h-[600px]">
            <img
              src="/img/dispersion.png"
              alt="Captura de página con content dispersion: bloques enormes, mucho whitespace, scroll infinito"
              className="w-full block"
            />
          </div>
          <p className="text-xs opacity-60 mt-2">
            Cada bloque ocupa una pantalla completa en desktop. El usuario tiene que hacer scroll repetidamente para encontrar la información que necesita comparar.
          </p>
        </div>
      </section>

      <section className="rounded-lg border border-[var(--border)] bg-[var(--card-bg)] p-4">
        <h2 className="font-bold mb-2">La síntesis</h2>
        <p className="text-sm opacity-80">
          Responsive desktop ≠ mobile escalado. Es un <strong>rediseño</strong> del layout para aprovechar el espacio disponible. La pantalla grande pide densidad de información útil, no celebraciones de whitespace.
        </p>
      </section>
    </div>
  )
}
