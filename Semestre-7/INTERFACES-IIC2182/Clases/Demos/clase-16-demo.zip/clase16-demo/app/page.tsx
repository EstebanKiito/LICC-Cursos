import Link from 'next/link'
import PageHeader from '@/components/PageHeader'

const demos = [
  { href: '/breakpoints', title: 'Breakpoints', desc: 'Tailwind sm/md/lg/xl en vivo. Indicador de breakpoint activo abajo a la derecha.' },
  { href: '/mobile-first-css', title: 'Mobile-first CSS', desc: 'min-width vs max-width: la diferencia práctica entre los dos enfoques.' },
  { href: '/fluid', title: 'Fluid units (clamp)', desc: 'Tipografía que escala continuamente vs saltos discretos por breakpoint.' },
  { href: '/container-queries', title: 'Container queries', desc: 'El mismo componente reacciona a su contenedor, no al viewport.' },
  { href: '/responsive-images', title: 'Imágenes responsive', desc: 'srcset y <picture> para distintas resoluciones y art direction.' },
  { href: '/layout-patterns', title: 'Patrones de layout', desc: 'Los 4 patrones canónicos de Wroblewski en acción.' },
  { href: '/touch-targets', title: 'Touch targets', desc: 'Comparación entre targets de 32px y 44px. Pruébalos con el dedo.' },
  { href: '/hide-show', title: 'Hide / show responsable', desc: 'Qué se puede esconder en mobile y qué nunca debe esconderse.' },
  { href: '/preferences', title: 'prefers-* queries', desc: 'Dark mode y reduced-motion respondiendo a preferencias del sistema.' },
  { href: '/dispersion', title: 'Content dispersion', desc: 'El antipatrón de NN/g — versión dispersada vs condensada.' },
]

export default function Home() {
  return (
    <div>
      <PageHeader
        title="Responsive Design — Demo"
        subtitle="Conceptos de la Clase 16, en vivo. Cambia el tamaño de la ventana para ver cómo responde cada demo."
        hint="Mira la insignia abajo a la derecha — te dice qué breakpoint de Tailwind está activo en tiempo real."
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {demos.map((d) => (
          <Link
            key={d.href}
            href={d.href}
            className="group block p-4 rounded-lg border border-[var(--border)] bg-[var(--card-bg)] hover:border-blue-400 transition-colors"
          >
            <div className="font-semibold mb-1 group-hover:text-blue-600 dark:group-hover:text-blue-400">
              {d.title}
            </div>
            <div className="text-sm opacity-70">{d.desc}</div>
          </Link>
        ))}
      </div>

      <section className="mt-12 p-4 rounded-lg border border-[var(--border)] bg-[var(--card-bg)]">
        <h2 className="font-bold mb-2">Cómo usar este demo</h2>
        <ol className="list-decimal pl-5 text-sm space-y-1 opacity-80">
          <li>Abre las DevTools del navegador (<kbd className="px-1 bg-black/10 dark:bg-white/10 rounded text-xs">F12</kbd>) y activa el modo responsive.</li>
          <li>Cambia el ancho del viewport mientras navegas cada sección.</li>
          <li>Observa la insignia inferior derecha que muestra el breakpoint activo.</li>
          <li>Para probar <code className="px-1 bg-black/10 dark:bg-white/10 rounded text-xs">prefers-*</code>, cambia el modo del sistema operativo o usa la sección de preferencias.</li>
        </ol>
      </section>
    </div>
  )
}
