import PageHeader from '@/components/PageHeader'

export default function MobileFirstPage() {
  return (
    <div>
      <PageHeader
        title="Mobile-first CSS"
        subtitle="La diferencia entre min-width (mobile-first) y max-width (desktop-first) en CSS no es solo sintaxis — refleja una filosofía distinta."
      />

      <div className="grid md:grid-cols-2 gap-4">
        <div className="rounded-lg border border-emerald-300 bg-emerald-50 dark:bg-emerald-950/30 p-4">
          <div className="font-bold text-emerald-700 dark:text-emerald-400 mb-2">
            ✓ Mobile-first (min-width)
          </div>
          <pre className="text-xs bg-black/5 dark:bg-white/5 p-3 rounded overflow-x-auto">
{`/* Base: aplica a TODOS los tamaños */
.card {
  padding: 1rem;
  font-size: 14px;
}

/* Solo en pantallas grandes: AGREGAR */
@media (min-width: 768px) {
  .card {
    padding: 2rem;
    font-size: 16px;
  }
}`}
          </pre>
          <p className="text-xs mt-3 opacity-80">
            Empiezas con lo mínimo y <strong>vas agregando</strong> a medida que hay más espacio. Mobile recibe lo esencial, desktop recibe extras.
          </p>
        </div>

        <div className="rounded-lg border border-rose-300 bg-rose-50 dark:bg-rose-950/30 p-4">
          <div className="font-bold text-rose-700 dark:text-rose-400 mb-2">
            ✗ Desktop-first (max-width)
          </div>
          <pre className="text-xs bg-black/5 dark:bg-white/5 p-3 rounded overflow-x-auto">
{`/* Base: estilos para desktop */
.card {
  padding: 2rem;
  font-size: 16px;
}

/* En pantallas pequeñas: SOBRESCRIBIR */
@media (max-width: 767px) {
  .card {
    padding: 1rem;
    font-size: 14px;
  }
}`}
          </pre>
          <p className="text-xs mt-3 opacity-80">
            Empiezas con lo grande y <strong>recortas</strong> en mobile. Más fácil que el contenido sobrante quede oculto en mobile.
          </p>
        </div>
      </div>

      <section className="mt-10">
        <h2 className="font-bold mb-4">Demo en vivo: la misma tarjeta, escrita ambas formas</h2>
        <div className="space-y-4">
          <div>
            <div className="text-xs opacity-60 mb-1 font-mono">
              p-2 sm:p-4 md:p-6 lg:p-8 (mobile-first)
            </div>
            <div className="bg-blue-100 dark:bg-blue-950 rounded p-2 sm:p-4 md:p-6 lg:p-8 transition-all">
              Padding crece desde la base hacia arriba.
            </div>
          </div>
          <div>
            <div className="text-xs opacity-60 mb-1 font-mono">
              text-xs sm:text-sm md:text-base lg:text-lg
            </div>
            <div className="bg-purple-100 dark:bg-purple-950 rounded p-3 text-xs sm:text-sm md:text-base lg:text-lg transition-all">
              El texto se agranda con el viewport.
            </div>
          </div>
        </div>
      </section>

      <section className="mt-10 p-4 rounded-lg border border-[var(--border)] bg-[var(--card-bg)]">
        <h2 className="font-bold mb-2">Por qué importa</h2>
        <ul className="text-sm space-y-2 list-disc pl-5 opacity-80">
          <li>
            <strong>Performance:</strong> mobile carga el CSS base sin sobrescribir nada — menos cascada, menos repaints.
          </li>
          <li>
            <strong>Mental model:</strong> piensas en escalar hacia arriba, no en recortar hacia abajo. Más alineado con progressive enhancement.
          </li>
          <li>
            <strong>Tailwind, Bootstrap 5+, Material:</strong> todos son mobile-first por default. Aprender uno, aprender todos.
          </li>
        </ul>
      </section>
    </div>
  )
}
