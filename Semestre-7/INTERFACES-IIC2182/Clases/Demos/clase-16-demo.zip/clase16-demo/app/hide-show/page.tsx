import PageHeader from '@/components/PageHeader'

export default function HideShowPage() {
  return (
    <div>
      <PageHeader
        title="Hide / show responsable"
        subtitle="Esconder en mobile es válido — si lo escondido es realmente secundario. Esconder lo crítico es destruir la experiencia mobile, no adaptarla."
      />

      <section className="mb-10">
        <h2 className="font-bold mb-3 text-emerald-700 dark:text-emerald-400">
          ✓ E-commerce — versión correcta
        </h2>
        <article className="rounded-lg border border-emerald-300 bg-[var(--card-bg)] overflow-hidden">
          <div className="grid sm:grid-cols-[1fr_2fr] gap-4 p-4">
            <div className="aspect-square bg-gradient-to-br from-blue-300 to-purple-400 rounded flex items-center justify-center text-white text-4xl font-bold">
              ☕
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg">Cafetera Italiana 6 tazas</h3>
              <div className="font-bold text-xl text-emerald-700 dark:text-emerald-400 mt-1">
                $24.990
              </div>
              <div className="text-xs opacity-60 mt-1">★★★★☆ (124 reseñas)</div>
              <p className="text-sm opacity-80 mt-2 hidden md:block">
                Cafetera Moka tradicional de aluminio. Compatible con todo tipo de cocinas excepto inducción.
              </p>
              <button className="mt-3 w-full sm:w-auto min-h-[44px] px-6 bg-emerald-600 text-white rounded font-bold">
                Agregar al carro
              </button>
            </div>
          </div>
        </article>
        <p className="text-xs opacity-70 mt-2">
          ✓ Precio, rating, CTA siempre visibles — incluso en mobile.<br />
          ✓ La descripción larga (secundaria) sí se esconde bajo el breakpoint md.
        </p>
      </section>

      <section className="mb-10">
        <h2 className="font-bold mb-3 text-rose-700 dark:text-rose-400">
          ✗ E-commerce — versión rota
        </h2>
        <article className="rounded-lg border border-rose-300 bg-[var(--card-bg)] overflow-hidden">
          <div className="p-4">
            <div className="aspect-video bg-gradient-to-br from-blue-300 to-purple-400 rounded flex items-center justify-center text-white text-4xl font-bold mb-3">
              ☕
            </div>
            <h3 className="font-bold text-base sm:text-lg">Cafetera Italiana 6 tazas</h3>
            <div className="hidden md:block">
              <div className="font-bold text-xl text-rose-700 dark:text-rose-400 mt-1">
                $24.990
              </div>
              <div className="text-xs opacity-60 mt-1">★★★★☆ (124 reseñas)</div>
            </div>
            <p className="text-sm opacity-80 mt-2 hidden md:block">
              Descripción importante.
            </p>
            <button className="mt-3 hidden md:inline-flex min-h-[44px] px-6 bg-rose-600 text-white rounded font-bold items-center">
              Agregar al carro
            </button>
            <button className="md:hidden mt-3 px-3 py-1 bg-gray-200 dark:bg-gray-800 rounded text-xs">
              Ver detalles →
            </button>
          </div>
        </article>
        <p className="text-xs opacity-70 mt-2">
          ✗ El precio, rating y CTA están escondidos bajo md.<br />
          ✗ El usuario en mobile tiene que hacer un clic extra solo para saber si puede comprar.
        </p>
      </section>

      <section className="grid md:grid-cols-2 gap-4 mb-10">
        <div className="rounded-lg border border-emerald-300 bg-emerald-50 dark:bg-emerald-950/30 p-4">
          <h3 className="font-bold text-sm mb-2 text-emerald-700 dark:text-emerald-400">
            ✓ OK esconder en mobile
          </h3>
          <ul className="text-sm space-y-1 list-disc pl-5 opacity-80">
            <li>Navegación secundaria (off-canvas)</li>
            <li>Imágenes decorativas, ilustraciones</li>
            <li>Filtros avanzados (drawer)</li>
            <li>Promociones cross-sell</li>
            <li>Descripciones largas (acordeón)</li>
          </ul>
        </div>

        <div className="rounded-lg border border-rose-300 bg-rose-50 dark:bg-rose-950/30 p-4">
          <h3 className="font-bold text-sm mb-2 text-rose-700 dark:text-rose-400">
            ✗ Nunca esconder
          </h3>
          <ul className="text-sm space-y-1 list-disc pl-5 opacity-80">
            <li><strong>CTAs principales</strong> (Comprar, Contactar)</li>
            <li><strong>Precios</strong> en e-commerce</li>
            <li>Información de contacto</li>
            <li>Search bar (recall vs recognition)</li>
            <li>Estado del pedido / del proceso</li>
          </ul>
        </div>
      </section>

      <section className="rounded-lg border border-[var(--border)] bg-[var(--card-bg)] p-4">
        <h2 className="font-bold mb-2">La regla</h2>
        <p className="text-sm opacity-80">
          El <strong>information scent</strong> debe quedar intacto: si escondes algo crítico, el usuario no sabe que existe.
          Esconder ≠ eliminar, pero <strong>esconder mal sí elimina la posibilidad de que el usuario lo encuentre</strong>.
        </p>
      </section>
    </div>
  )
}
