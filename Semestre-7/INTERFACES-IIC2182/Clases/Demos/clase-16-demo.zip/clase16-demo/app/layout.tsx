import type { Metadata, Viewport } from "next";
import Link from "next/link";
import "./globals.css";
import BreakpointBadge from "@/components/BreakpointBadge";

export const metadata: Metadata = {
  title: "Responsive Design Demo — IIC2182 Clase 16",
  description: "Demo interactivo de los conceptos de responsive design",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
};

const sections = [
  { href: "/", label: "Inicio", icon: "◎" },
  { href: "/breakpoints", label: "Breakpoints", icon: "⊟" },
  { href: "/mobile-first-css", label: "Mobile-first CSS", icon: "⊞" },
  { href: "/fluid", label: "Fluid units (clamp)", icon: "∿" },
  { href: "/container-queries", label: "Container queries", icon: "◧" },
  { href: "/responsive-images", label: "Imágenes responsive", icon: "▣" },
  { href: "/layout-patterns", label: "Patrones de layout", icon: "⊞" },
  { href: "/touch-targets", label: "Touch targets", icon: "◉" },
  { href: "/hide-show", label: "Hide / show", icon: "◐" },
];

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es">
      <body className="min-h-screen">
        <BreakpointBadge />
        <div className="flex flex-col lg:flex-row min-h-screen">
          <aside className="lg:w-64 lg:min-h-screen lg:border-r border-b lg:border-b-0 border-[var(--border)] bg-[var(--card-bg)]">
            <div className="p-4 border-b border-[var(--border)]">
              <Link href="/" className="block font-bold text-base">
                Responsive Demo
              </Link>
              <span className="text-xs opacity-60">IIC2182 — Clase 16</span>
            </div>
            <nav className="p-2 flex lg:flex-col gap-1 overflow-x-auto lg:overflow-visible">
              {sections.map((s) => (
                <Link
                  key={s.href}
                  href={s.href}
                  className="flex items-center gap-2 px-3 py-2 rounded-md text-sm hover:bg-black/5 dark:hover:bg-white/5 whitespace-nowrap min-h-[44px]"
                >
                  <span className="opacity-60 w-4 text-center">{s.icon}</span>
                  <span>{s.label}</span>
                </Link>
              ))}
            </nav>
          </aside>
          <main className="flex-1 p-4 sm:p-6 lg:p-10 max-w-5xl">
            {children}
          </main>
        </div>
      </body>
    </html>
  );
}
