import PageHeader from '@/components/PageHeader'

export default function FluidPage() {
  return (
    <div>
      <PageHeader
        title="Fluid units — clamp()"
        subtitle="En vez de saltos discretos en cada breakpoint, una progresión continua entre un mínimo y un máximo."
        hint="Cambia el ancho del navegador lentamente — el texto fluye en vez de saltar."
      />

      <section className="space-y-8">
        <div>
          <h2 className="font-bold mb-3">1. Tipografía con saltos vs fluida</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="rounded-lg border border-[var(--border)] bg-[var(--card-bg)] p-4">
              <div className="text-xs opacity-60 mb-2 font-mono">
                text-base md:text-2xl lg:text-4xl (saltos)
              </div>
              <h3 className="font-bold text-base md:text-2xl lg:text-4xl">
                Salto en breakpoints
              </h3>
              <p className="text-xs opacity-60 mt-2">
                Cambia bruscamente al cruzar 768px y 1024px.
              </p>
            </div>

            <div className="rounded-lg border border-[var(--border)] bg-[var(--card-bg)] p-4">
              <div className="text-xs opacity-60 mb-2 font-mono">
                clamp(1rem, 2vw + 1rem, 3rem)
              </div>
              <h3
                className="font-bold"
                style={{ fontSize: 'clamp(1rem, 2vw + 1rem, 3rem)' }}
              >
                Fluyo continuamente
              </h3>
              <p className="text-xs opacity-60 mt-2">
                Crece suavemente con el ancho.
              </p>
            </div>
          </div>
        </div>

        <div>
          <h2 className="font-bold mb-3">2. Anatomía de clamp()</h2>
          <div className="rounded-lg border border-[var(--border)] bg-[var(--card-bg)] p-5">
            <pre className="text-sm font-mono bg-black/5 dark:bg-white/5 p-3 rounded overflow-x-auto">
{`font-size: clamp(1rem, 2vw + 1rem, 3rem);
                 ─┬──  ─────┬─────  ─┬─
                  │         │        │
                  │         │        └── max: nunca crece más que esto
                  │         └── preferred: tamaño ideal (depende del viewport)
                  └── min: nunca cae bajo esto`}
            </pre>
            <p className="text-sm mt-3 opacity-80">
              El navegador elige <code className="text-xs bg-black/10 dark:bg-white/10 px-1 rounded">preferred</code> mientras esté entre <code className="text-xs bg-black/10 dark:bg-white/10 px-1 rounded">min</code> y <code className="text-xs bg-black/10 dark:bg-white/10 px-1 rounded">max</code>. Si lo excede, lo clamp&quot;ea (recorta) al borde.
            </p>
          </div>
        </div>

        <div>
          <h2 className="font-bold mb-3">3. clamp() también para spacing</h2>
          <div
            className="rounded-lg bg-emerald-100 dark:bg-emerald-950 transition-all"
            style={{ padding: 'clamp(0.5rem, 3vw, 3rem)' }}
          >
            <div className="bg-white dark:bg-black rounded p-3 text-sm">
              El padding de la caja exterior es <code className="text-xs bg-black/10 dark:bg-white/10 px-1 rounded">clamp(0.5rem, 3vw, 3rem)</code>.
              <br />
              En mobile el padding es ~8px, en desktop hasta 48px.
            </div>
          </div>
        </div>

        <div>
          <h2 className="font-bold mb-3">4. Tipografía fluida real</h2>
          <article className="rounded-lg border border-[var(--border)] bg-[var(--card-bg)] p-6 space-y-3">
            <h1 className="fluid-heading">Una entrada de blog</h1>
            <p className="fluid-body opacity-80">
              Este encabezado y este cuerpo usan las clases <code className="text-xs bg-black/10 dark:bg-white/10 px-1 rounded">.fluid-heading</code> y <code className="text-xs bg-black/10 dark:bg-white/10 px-1 rounded">.fluid-body</code> definidas en el CSS global. Ambas usan clamp() bajo la capa.
            </p>
            <p className="fluid-body opacity-80">
              No hay un solo media query. Sin embargo, el resultado se siente apropiado en cualquier viewport — sin necesidad de definir cinco breakpoints distintos.
            </p>
          </article>
        </div>
      </section>
    </div>
  )
}
