'use client'

import { useEffect, useRef, useState } from 'react'

type Props = {
  src: string
  srcSet?: string
  sizes?: string
  alt: string
  className?: string
}

export default function CurrentSrcImg({ src, srcSet, sizes, alt, className }: Props) {
  const ref = useRef<HTMLImageElement>(null)
  const [info, setInfo] = useState<{ currentSrc: string; viewport: number } | null>(null)

  useEffect(() => {
    const update = () => {
      const img = ref.current
      if (!img) return
      setInfo({
        currentSrc: img.currentSrc || img.src,
        viewport: window.innerWidth,
      })
    }
    update()
    const onResize = () => update()
    window.addEventListener('resize', onResize)
    const interval = window.setInterval(update, 250)
    return () => {
      window.removeEventListener('resize', onResize)
      window.clearInterval(interval)
    }
  }, [])

  const filename = info?.currentSrc.split('/').pop() ?? ''

  return (
    <div>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        ref={ref}
        src={src}
        srcSet={srcSet}
        sizes={sizes}
        alt={alt}
        className={className}
        onLoad={() => {
          const img = ref.current
          if (img) {
            setInfo({
              currentSrc: img.currentSrc || img.src,
              viewport: window.innerWidth,
            })
          }
        }}
      />
      {info && (
        <div className="mt-2 flex flex-wrap gap-2 text-xs font-mono">
          <span className="px-2 py-1 rounded bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300">
            viewport: {info.viewport}px
          </span>
          <span className="px-2 py-1 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold">
            cargado: {filename}
          </span>
          <span className="px-2 py-1 rounded bg-black/[.05] dark:bg-white/[.05] opacity-70">
            DPR: {typeof window !== 'undefined' ? window.devicePixelRatio : 1}×
          </span>
        </div>
      )}
    </div>
  )
}
