export default function PageHeader({
  title,
  subtitle,
  hint,
}: {
  title: string
  subtitle?: string
  hint?: string
}) {
  return (
    <header className="mb-8 pb-4 border-b border-[var(--border)]">
      <h1 className="fluid-heading">{title}</h1>
      {subtitle && (
        <p className="mt-2 fluid-body opacity-70">{subtitle}</p>
      )}
      {hint && (
        <div className="mt-3 inline-flex items-start gap-2 px-3 py-2 rounded bg-amber-50 dark:bg-amber-950/30 text-xs">
          <span className="text-amber-600 dark:text-amber-400">💡</span>
          <span>{hint}</span>
        </div>
      )}
    </header>
  )
}
