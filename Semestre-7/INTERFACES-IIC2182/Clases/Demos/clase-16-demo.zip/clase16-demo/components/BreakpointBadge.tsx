'use client'

export default function BreakpointBadge() {
  return (
    <div
      className="fixed bottom-4 right-4 z-50 px-3 py-2 rounded-full bg-black text-white text-xs font-mono shadow-lg pointer-events-none"
      aria-hidden
    >
      <span className="opacity-50">bp:</span>{' '}
      <span className="sm:hidden">base (&lt;640)</span>
      <span className="hidden sm:inline md:hidden">sm (≥640)</span>
      <span className="hidden md:inline lg:hidden">md (≥768)</span>
      <span className="hidden lg:inline xl:hidden">lg (≥1024)</span>
      <span className="hidden xl:inline 2xl:hidden">xl (≥1280)</span>
      <span className="hidden 2xl:inline">2xl (≥1536)</span>
    </div>
  )
}
