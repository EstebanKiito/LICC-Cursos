'use client'

import { useState } from 'react'

const MD_BREAKPOINT_PX = 448

export default function ResizableContainer({
  children,
  initial = 300,
}: {
  children: React.ReactNode
  initial?: number
}) {
  const [width, setWidth] = useState(initial)
  const mdActive = width >= MD_BREAKPOINT_PX

  return (
    <div>
      <div className="mb-3 rounded-lg border border-[var(--border)] bg-[var(--card-bg)] p-3">
        <div className="flex items-center gap-3 flex-wrap">
          <label className="text-sm font-bold whitespace-nowrap">Ancho del contenedor:</label>
          <input
            type="range"
            min={150}
            max={800}
            value={width}
            onChange={(e) => setWidth(Number(e.target.value))}
            className="flex-1 min-w-[200px]"
          />
          <span className="px-3 py-1 rounded bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300 font-mono font-bold text-sm tabular-nums w-20 text-center">
            {width}px
          </span>
        </div>
        <div className="mt-2 flex items-center gap-2 text-xs">
          <span
            className={`px-2 py-0.5 rounded font-mono ${
              mdActive
                ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                : 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300'
            }`}
          >
            @md {mdActive ? 'activa' : 'inactiva'} (umbral: {MD_BREAKPOINT_PX}px)
          </span>
          <span className="opacity-60">
            {mdActive
              ? '→ layout horizontal, descripción visible'
              : '→ layout vertical, descripción oculta'}
          </span>
        </div>
      </div>

      <div
        className="rounded-lg border-2 border-dashed border-blue-400/60 p-3 transition-[width] duration-150"
        style={{ width: `${width}px`, maxWidth: '100%' }}
      >
        {children}
      </div>
    </div>
  )
}
