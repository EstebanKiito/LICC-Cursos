'use client'

import { useEffect, useRef, useState } from 'react'

const MD_BREAKPOINT_PX = 448 // 28rem en Tailwind container-queries

export default function MeasuredContainer({
  label,
  children,
  style,
}: {
  label: string
  children: React.ReactNode
  style?: React.CSSProperties
}) {
  const ref = useRef<HTMLDivElement>(null)
  const [width, setWidth] = useState<number | null>(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    const observer = new ResizeObserver((entries) => {
      const w = entries[0]?.contentRect.width
      if (typeof w === 'number') setWidth(Math.round(w))
    })
    observer.observe(el)
    return () => observer.disconnect()
  }, [])

  const mdActive = width !== null && width >= MD_BREAKPOINT_PX

  return (
    <div ref={ref} style={style}>
      <div className="mb-2 flex items-center gap-2 flex-wrap text-xs font-mono">
        <span className="px-2 py-0.5 rounded bg-black/[.06] dark:bg-white/[.06]">
          {label}
        </span>
        {width !== null && (
          <span className="px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300 font-bold">
            {width}px
          </span>
        )}
        <span
          className={`px-2 py-0.5 rounded ${
            mdActive
              ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
              : 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300'
          }`}
        >
          {mdActive ? '@md activa' : '@md inactiva'}
        </span>
      </div>
      {children}
    </div>
  )
}
