'use client'

import { useEffect, useRef, useState } from 'react'

const SRC_SET =
  '/img/hero-400.png 400w, /img/hero-800.png 800w, /img/hero-1600.png 1600w'

function pickBucket(needPx: number): '400' | '800' | '1600' {
  if (needPx <= 400) return '400'
  if (needPx <= 800) return '800'
  return '1600'
}

export default function ResponsiveImageDemo() {
  const [width, setWidth] = useState(300)
  const [dpr, setDpr] = useState(1)
  const [loaded, setLoaded] = useState<string>('')
  const ref = useRef<HTMLImageElement>(null)

  useEffect(() => {
    setDpr(window.devicePixelRatio || 1)
  }, [])

  const need = Math.round(width * dpr)
  const bucket = pickBucket(need)

  return (
    <div>
      <div className="mb-3 rounded-lg border border-[var(--border)] bg-[var(--card-bg)] p-3">
        <div className="flex items-center gap-3 flex-wrap">
          <label className="text-sm font-bold whitespace-nowrap">Ancho del contenedor:</label>
          <input
            type="range"
            min={150}
            max={800}
            value={width}
            onChange={(e) => setWidth(Number(e.target.value))}
            className="flex-1 min-w-[200px]"
          />
          <span className="px-3 py-1 rounded bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300 font-mono font-bold text-sm tabular-nums w-20 text-center">
            {width}px
          </span>
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-2 text-xs font-mono">
          <span className="px-2 py-0.5 rounded bg-black/[.05] dark:bg-white/[.05]">
            DPR: {dpr}×
          </span>
          <span className="px-2 py-0.5 rounded bg-black/[.05] dark:bg-white/[.05]">
            necesidad: {width} × {dpr} = <strong>{need}px</strong>
          </span>
          <span className="opacity-60">→ menor srcset que cubra ≥ {need}px</span>
        </div>
      </div>

      <div
        className="rounded-lg border-2 border-dashed border-blue-400/60 p-3 transition-[width] duration-100"
        style={{ width: `${width}px`, maxWidth: '100%' }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          key={bucket}
          ref={ref}
          src="/img/hero-800.png"
          srcSet={SRC_SET}
          sizes={`${width}px`}
          alt="Demo srcset"
          className="w-full rounded block"
          onLoad={() => {
            const img = ref.current
            if (img) setLoaded(img.currentSrc.split('/').pop() ?? '')
          }}
        />
      </div>

      <div className="mt-2 flex flex-wrap gap-2 text-xs font-mono">
        <span className="px-2 py-1 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold">
          cargado: {loaded || '...'}
        </span>
        <span className="px-2 py-1 rounded bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300">
          bucket esperado: hero-{bucket}.svg
        </span>
      </div>

      <p className="text-xs opacity-60 mt-2 leading-relaxed">
        <strong>Nota técnica:</strong> los browsers nunca degradan una imagen ya cargada (si bajas el viewport, mantienen la versión grande). Para que el demo demuestre la elección bidireccional, este componente <strong>remonta</strong> el <code className="bg-black/10 dark:bg-white/10 px-1 rounded">&lt;img&gt;</code> cuando cambia el bucket — así el browser reevalúa <code className="bg-black/10 dark:bg-white/10 px-1 rounded">srcset</code> desde cero. En producción no haces esto: se acepta que solo sube de calidad.
      </p>
    </div>
  )
}
