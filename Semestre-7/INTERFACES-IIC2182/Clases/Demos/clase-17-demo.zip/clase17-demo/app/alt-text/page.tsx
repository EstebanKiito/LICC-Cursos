'use client'

import { useState } from 'react'
import { PageHeader } from '../components/PageHeader'

type Choice = {
  id: string
  label: string
  isBest: boolean
  feedback: string
}

const QUESTIONS: {
  id: string
  question: string
  scenario: string
  choices: Choice[]
}[] = [
  {
    id: 'cart',
    question: 'Ícono de carrito que lleva al checkout',
    scenario:
      'Es una imagen funcional: hace algo (navegar al checkout). El alt debe describir la acción.',
    choices: [
      {
        id: 'a',
        label: 'alt="ícono de carrito de compras"',
        isBest: false,
        feedback:
          'Describe la forma, no la función. El usuario no sabe a dónde va al activarlo.',
      },
      {
        id: 'b',
        label: 'alt="Ver carrito"',
        isBest: true,
        feedback:
          'Describe la acción que ocurre al activarlo. Esto es lo que el usuario necesita saber.',
      },
      {
        id: 'c',
        label: 'alt=""',
        isBest: false,
        feedback:
          'alt vacío es para imágenes decorativas. Una imagen que activa una acción nunca debe ser invisible para lectores de pantalla.',
      },
    ],
  },
  {
    id: 'hero',
    question: 'Foto de fondo decorativa en una landing page',
    scenario:
      'La foto no aporta información — es solo ambiente. El texto principal cuenta toda la historia.',
    choices: [
      {
        id: 'a',
        label: 'alt="Fondo abstracto con tonos púrpura"',
        isBest: false,
        feedback:
          'Interrumpe la lectura con un detalle irrelevante. "IMAGEN: fondo abstracto..." rompe el ritmo.',
      },
      {
        id: 'b',
        label: 'alt="Imagen decorativa"',
        isBest: false,
        feedback:
          'Decirlo igual lo anuncia. Mejor saltar la imagen por completo.',
      },
      {
        id: 'c',
        label: 'alt=""',
        isBest: true,
        feedback:
          'Correcto. El lector de pantalla la salta. Si tu mano cubre la imagen y el sentido del contenido no cambia, no necesita alt.',
      },
    ],
  },
  {
    id: 'chart',
    question: 'Gráfico con datos importantes del informe',
    scenario:
      'El gráfico tiene información que el usuario necesita: ventas por trimestre, con un trimestre destacado.',
    choices: [
      {
        id: 'a',
        label: 'alt="gráfico de barras"',
        isBest: false,
        feedback:
          'No comunica los datos. Un lector de pantalla solo escucha "gráfico de barras" y se queda sin la información.',
      },
      {
        id: 'b',
        label:
          'alt="Ventas trimestrales 2025: Q1 $1.2M, Q2 $1.5M, Q3 $2.1M (récord), Q4 $1.8M"',
        isBest: true,
        feedback:
          'Comunica los datos. Para gráficos complejos, considerá además una tabla accesible cercana.',
      },
      {
        id: 'c',
        label: 'alt=""',
        isBest: false,
        feedback:
          'Estás escondiendo información crítica. Solo usar alt vacío si es decorativa.',
      },
    ],
  },
]

export default function AltTextPage() {
  return (
    <>
      <PageHeader
        title="Texto alternativo en la práctica"
        description="No hay fórmula única, pero sí preguntas útiles. Probá responder los ejercicios."
        takeaway="Escribilo como si se lo leyeras a alguien por teléfono. Si no aporta, no lo digas."
      />

      <section
        aria-labelledby="rules"
        className="mb-10 rounded-xl border-2 border-purple-200 bg-purple-50 p-5"
      >
        <h2 id="rules" className="text-lg font-bold text-purple-900">
          Las cuatro preguntas
        </h2>
        <ul className="mt-3 space-y-2 text-sm text-zinc-800">
          <li>
            <strong>¿La imagen hace algo?</strong> → describí la función, no la
            forma.
          </li>
          <li>
            <strong>¿Es significativa?</strong> → contá qué muestra y por qué
            importa.
          </li>
          <li>
            <strong>¿Es decorativa?</strong> → sáltala con <code>alt=""</code>.
          </li>
          <li>
            <strong>¿Mejor como caption?</strong> → si el contexto importa para
            todes, no solo para lectores de pantalla.
          </li>
        </ul>
      </section>

      <section aria-labelledby="ejercicio">
        <h2 id="ejercicio" className="text-lg font-bold text-zinc-900">
          Ejercicio: elegí el mejor alt
        </h2>

        <div className="mt-4 space-y-6">
          {QUESTIONS.map((q) => (
            <Question key={q.id} {...q} />
          ))}
        </div>
      </section>
    </>
  )
}

function Question({
  id,
  question,
  scenario,
  choices,
}: {
  id: string
  question: string
  scenario: string
  choices: Choice[]
}) {
  const [selected, setSelected] = useState<string | null>(null)
  const selectedChoice = choices.find((c) => c.id === selected)

  return (
    <fieldset className="rounded-xl border-2 border-zinc-200 bg-white p-5">
      <legend className="px-2 text-sm font-bold text-purple-700">
        {question}
      </legend>
      <p className="text-sm text-zinc-700">{scenario}</p>

      <div className="mt-4 space-y-2">
        {choices.map((c) => {
          const inputId = `${id}-${c.id}`
          const isSelected = selected === c.id
          const isCorrect = c.isBest
          const className = isSelected
            ? isCorrect
              ? 'border-green-500 bg-green-50'
              : 'border-rose-500 bg-rose-50'
            : 'border-zinc-300 bg-white hover:bg-zinc-50'

          return (
            <label
              key={c.id}
              htmlFor={inputId}
              className={`flex cursor-pointer items-start gap-3 rounded-lg border-2 p-3 text-sm transition ${className}`}
            >
              <input
                id={inputId}
                type="radio"
                name={id}
                value={c.id}
                checked={isSelected}
                onChange={() => setSelected(c.id)}
                className="mt-0.5"
                aria-describedby={isSelected ? `${id}-feedback` : undefined}
              />
              <code className="flex-1 font-mono text-xs">{c.label}</code>
            </label>
          )
        })}
      </div>

      {selectedChoice && (
        <p
          id={`${id}-feedback`}
          role="alert"
          className={`mt-3 rounded-lg p-3 text-sm ${
            selectedChoice.isBest
              ? 'bg-green-100 text-green-900'
              : 'bg-amber-100 text-amber-900'
          }`}
        >
          {selectedChoice.isBest ? '✓ Correcto. ' : '✗ No es la mejor. '}
          {selectedChoice.feedback}
        </p>
      )}
    </fieldset>
  )
}
