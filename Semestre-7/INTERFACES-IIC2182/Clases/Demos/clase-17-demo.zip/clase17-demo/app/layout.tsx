import type { Metadata } from 'next'
import './globals.css'
import { Nav } from './components/Nav'

export const metadata: Metadata = {
  title: 'Clase 17 — Accesibilidad Web',
  description: 'Demo interactivo de accesibilidad web para IIC2182',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es">
      <body>
        <a href="#main" className="skip-link">
          Saltar al contenido principal
        </a>
        <Nav />
        <main id="main" tabIndex={-1} className="mx-auto max-w-5xl px-4 py-10">
          {children}
        </main>
        <footer className="mt-16 border-t border-zinc-200 bg-white py-6 text-center text-xs text-zinc-500">
          IIC2182 — Clase 17 — Accesibilidad Web
        </footer>
      </body>
    </html>
  )
}
