'use client'

import { useState } from 'react'
import { useForm, type FieldErrors } from 'react-hook-form'
import { PageHeader } from '../../components/PageHeader'

type FormData = {
  email: string
  password: string
}

export default function GoodFormPage() {
  const [submittedEmail, setSubmittedEmail] = useState<string | null>(null)

  const {
    register,
    handleSubmit,
    setFocus,
    reset,
    formState: { errors, isSubmitted },
  } = useForm<FormData>({
    mode: 'onSubmit',
    reValidateMode: 'onBlur',
  })

  const onValid = (data: FormData) => {
    setSubmittedEmail(data.email)
    reset()
  }

  const onInvalid = (formErrors: FieldErrors<FormData>) => {
    // Focus the first invalid field — critical for keyboard users.
    const firstError = Object.keys(formErrors)[0] as keyof FormData | undefined
    if (firstError) setFocus(firstError)
  }

  return (
    <>
      <PageHeader
        title="Formulario accesible"
        description="Mismo login, ahora pensado para que funcione con teclado, lector de pantalla y bajo estrés."
        takeaway="Cada atributo ARIA aquí responde a una necesidad humana concreta — no es solo 'cumplir el WCAG'."
      />

      <div className="grid gap-8 md:grid-cols-[1fr_1.1fr]">
        <form
          onSubmit={handleSubmit(onValid, onInvalid)}
          noValidate
          aria-labelledby="login-heading"
          className="rounded-xl border-2 border-green-200 bg-white p-6"
        >
          <h2 id="login-heading" className="mb-4 font-bold text-green-700">
            Login
          </h2>

          {/* Resumen anunciado por aria-live cuando hay errores */}
          {isSubmitted && Object.keys(errors).length > 0 && (
            <div
              role="alert"
              className="mb-4 rounded-lg border-2 border-rose-300 bg-rose-50 p-3 text-sm text-rose-800"
            >
              <strong>Hay {Object.keys(errors).length} error(es).</strong>{' '}
              Revisa los campos marcados abajo.
            </div>
          )}

          <Field
            id="email"
            label="Email"
            hint="Lo usaremos solo para iniciar sesión."
            error={errors.email?.message}
            type="email"
            autoComplete="email"
            register={register('email', {
              required: 'Ingresa tu email',
              pattern: {
                value: /^\S+@\S+\.\S+$/,
                message: 'Formato de email inválido (ej: tu@correo.com)',
              },
            })}
          />

          <Field
            id="password"
            label="Contraseña"
            hint="Mínimo 8 caracteres."
            error={errors.password?.message}
            type="password"
            autoComplete="current-password"
            register={register('password', {
              required: 'Ingresa tu contraseña',
              minLength: {
                value: 8,
                message: 'La contraseña debe tener al menos 8 caracteres',
              },
            })}
          />

          <button
            type="submit"
            className="mt-6 w-full rounded-lg bg-green-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-green-800"
          >
            Entrar
          </button>

          {/* Confirmación de éxito anunciada por aria-live */}
          <div
            role="status"
            aria-live="polite"
            className="mt-4 text-sm text-green-700"
          >
            {submittedEmail && (
              <p>¡Bienvenide! Sesión iniciada como {submittedEmail}.</p>
            )}
          </div>
        </form>

        <aside aria-labelledby="why" className="text-sm">
          <h2 id="why" className="mb-3 font-bold text-zinc-900">
            ¿Por qué funciona?
          </h2>
          <ul className="space-y-3">
            <Yes>
              <strong>
                <code>&lt;label htmlFor&gt;</code> visible y persistente:
              </strong>{' '}
              clic en la label enfoca el campo (útil en mobile).
            </Yes>
            <Yes>
              <strong><code>aria-invalid</code>:</strong> el lector de pantalla
              anuncia "campo inválido" — no depende solo del rojo.
            </Yes>
            <Yes>
              <strong><code>aria-describedby</code>:</strong> el hint (o el
              error, si aparece) se anuncia <em>junto</em> con la label.
            </Yes>
            <Yes>
              <strong><code>role="alert"</code>:</strong> el resumen se anuncia
              en cuanto aparece, sin que el usuario deba buscarlo.
            </Yes>
            <Yes>
              <strong>
                <code>setFocus</code> de react-hook-form:
              </strong>{' '}
              al fallar, el foco vuelve al primer campo con error.
            </Yes>
            <Yes>
              <strong><code>autoComplete</code>:</strong> el navegador puede
              rellenar — clave para personas con discapacidad motora o
              cognitiva.
            </Yes>
            <Yes>
              <strong>Mensajes accionables:</strong> "Ingresa tu email" supera a
              "Campo requerido". Dile <em>qué</em> hacer.
            </Yes>
          </ul>

          <h3 className="mt-6 font-bold text-zinc-900">Probá esto</h3>
          <ol className="mt-2 list-decimal space-y-1 pl-5 text-zinc-700">
            <li>Tab + Enter sin tocar el mouse.</li>
            <li>Submit con campos vacíos: ¿a dónde va el foco?</li>
            <li>Activá VoiceOver y escuchá cómo se anuncian errores.</li>
          </ol>
        </aside>
      </div>
    </>
  )
}

// ---------------------------------------------------------------------------
// Reusable accessible field
// ---------------------------------------------------------------------------
type FieldProps = {
  id: string
  label: string
  hint?: string
  error?: string
  type?: string
  autoComplete?: string
  register: ReturnType<ReturnType<typeof useForm<FormData>>['register']>
}

function Field({
  id,
  label,
  hint,
  error,
  type = 'text',
  autoComplete,
  register,
}: FieldProps) {
  const hintId = hint ? `${id}-hint` : undefined
  const errorId = error ? `${id}-error` : undefined
  // aria-describedby concatenates both ids — both are announced.
  const describedBy = [errorId, hintId].filter(Boolean).join(' ') || undefined

  return (
    <div className="mt-4">
      <label htmlFor={id} className="block text-sm font-semibold text-zinc-900">
        {label}
      </label>

      <input
        id={id}
        type={type}
        autoComplete={autoComplete}
        aria-invalid={error ? 'true' : 'false'}
        aria-describedby={describedBy}
        className={`mt-1 w-full rounded-md border-2 px-3 py-2 text-sm ${
          error
            ? 'border-rose-500 bg-rose-50'
            : 'border-zinc-300 bg-white focus:border-green-600'
        }`}
        {...register}
      />

      {hint && (
        <p id={hintId} className="mt-1 text-xs text-zinc-500">
          {hint}
        </p>
      )}

      {error && (
        <p
          id={errorId}
          className="mt-1 flex items-center gap-1 text-xs font-semibold text-rose-700"
        >
          <span aria-hidden="true">⚠</span>
          {error}
        </p>
      )}
    </div>
  )
}

function Yes({ children }: { children: React.ReactNode }) {
  return (
    <li className="flex items-start gap-2">
      <span aria-hidden="true" className="text-green-600">
        ✓
      </span>
      <span>{children}</span>
    </li>
  )
}
