'use client'

import { useEffect } from 'react'
import { useForm, type FieldErrors } from 'react-hook-form'
import { PageHeader } from '../../components/PageHeader'

type CheckoutData = {
  fullName: string
  email: string
  phone: string
  address: string
  city: string
  zip: string
  sameAsShipping: boolean
  billingAddress?: string
  billingCity?: string
  billingZip?: string
  cardNumber: string
  cardExpiry: string
  cardCvv: string
}

const initial: Partial<CheckoutData> = { sameAsShipping: true }

export default function CheckoutPage() {
  const {
    register,
    handleSubmit,
    watch,
    setFocus,
    formState: { errors, isSubmitted, isSubmitSuccessful },
  } = useForm<CheckoutData>({
    defaultValues: initial,
    mode: 'onBlur',
  })

  const sameAsShipping = watch('sameAsShipping')

  const onValid = (data: CheckoutData) => {
    console.log('Order submitted:', data)
  }

  const onInvalid = (formErrors: FieldErrors<CheckoutData>) => {
    const order: (keyof CheckoutData)[] = [
      'fullName',
      'email',
      'phone',
      'address',
      'city',
      'zip',
      'billingAddress',
      'billingCity',
      'billingZip',
      'cardNumber',
      'cardExpiry',
      'cardCvv',
    ]
    const firstError = order.find((k) => formErrors[k])
    if (firstError) setFocus(firstError)
  }

  // Cuando el usuario destildaba "mismo que envío", llevar el foco al primer
  // campo de facturación para que sepa qué hacer ahora.
  useEffect(() => {
    if (!sameAsShipping) {
      setFocus('billingAddress')
    }
  }, [sameAsShipping, setFocus])

  return (
    <>
      <PageHeader
        title="Checkout accesible"
        description="Un flujo de compra real con fieldsets, autocomplete, 'mismo que envío' y validación on-blur."
        takeaway="Repetir 'la misma dirección' es accesibilidad — no solo conveniencia."
      />

      <form
        onSubmit={handleSubmit(onValid, onInvalid)}
        noValidate
        className="space-y-8"
        aria-describedby={
          isSubmitted && Object.keys(errors).length > 0
            ? 'form-error-summary'
            : undefined
        }
      >
        {isSubmitted && Object.keys(errors).length > 0 && (
          <div
            id="form-error-summary"
            role="alert"
            className="rounded-lg border-2 border-rose-300 bg-rose-50 p-4 text-sm text-rose-900"
          >
            <strong>
              Hay {Object.keys(errors).length} error(es) en el formulario.
            </strong>
            <ul className="mt-2 list-disc pl-5">
              {Object.entries(errors).map(([key, err]) => (
                <li key={key}>
                  <a
                    href={`#${key}`}
                    className="font-semibold underline hover:no-underline"
                  >
                    {err?.message?.toString() ?? 'Campo inválido'}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        )}

        {isSubmitSuccessful && (
          <div
            role="status"
            aria-live="polite"
            className="rounded-lg border-2 border-green-300 bg-green-50 p-4 text-sm text-green-900"
          >
            ¡Orden recibida! Te enviamos un email con la confirmación.
          </div>
        )}

        {/* ----- Contacto ----- */}
        <Section legend="Datos de contacto">
          <Row>
            <Field
              id="fullName"
              label="Nombre completo"
              autoComplete="name"
              error={errors.fullName?.message}
              register={register('fullName', {
                required: 'Ingresa tu nombre completo',
              })}
            />
            <Field
              id="email"
              label="Email"
              type="email"
              autoComplete="email"
              hint="Te enviaremos la confirmación aquí."
              error={errors.email?.message}
              register={register('email', {
                required: 'Ingresa tu email',
                pattern: {
                  value: /^\S+@\S+\.\S+$/,
                  message: 'Formato inválido (ej: tu@correo.com)',
                },
              })}
            />
            <Field
              id="phone"
              label="Teléfono"
              type="tel"
              autoComplete="tel"
              hint="Solo lo usamos si hay un problema con tu pedido."
              error={errors.phone?.message}
              register={register('phone', {
                required: 'Ingresa un teléfono',
              })}
            />
          </Row>
        </Section>

        {/* ----- Envío ----- */}
        <Section legend="Dirección de envío">
          <Row>
            <Field
              id="address"
              label="Dirección"
              autoComplete="shipping street-address"
              error={errors.address?.message}
              register={register('address', {
                required: 'Ingresa tu dirección',
              })}
            />
            <Field
              id="city"
              label="Ciudad"
              autoComplete="shipping address-level2"
              error={errors.city?.message}
              register={register('city', {
                required: 'Ingresa tu ciudad',
              })}
            />
            <Field
              id="zip"
              label="Código postal"
              autoComplete="shipping postal-code"
              hint="Formato: 1234567"
              error={errors.zip?.message}
              register={register('zip', {
                required: 'Ingresa tu código postal',
              })}
            />
          </Row>
        </Section>

        {/* ----- Facturación ----- */}
        <Section legend="Dirección de facturación">
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              {...register('sameAsShipping')}
              className="h-4 w-4 rounded border-zinc-400"
            />
            <span>
              <strong>La misma que la de envío</strong> — evita reescribirla.
            </span>
          </label>

          {!sameAsShipping && (
            <Row>
              <Field
                id="billingAddress"
                label="Dirección de facturación"
                autoComplete="billing street-address"
                error={errors.billingAddress?.message}
                register={register('billingAddress', {
                  required: !sameAsShipping
                    ? 'Ingresa la dirección de facturación'
                    : false,
                })}
              />
              <Field
                id="billingCity"
                label="Ciudad"
                autoComplete="billing address-level2"
                error={errors.billingCity?.message}
                register={register('billingCity', {
                  required: !sameAsShipping ? 'Ingresa la ciudad' : false,
                })}
              />
              <Field
                id="billingZip"
                label="Código postal"
                autoComplete="billing postal-code"
                error={errors.billingZip?.message}
                register={register('billingZip', {
                  required: !sameAsShipping
                    ? 'Ingresa el código postal'
                    : false,
                })}
              />
            </Row>
          )}
        </Section>

        {/* ----- Pago ----- */}
        <Section legend="Pago">
          <Row>
            <Field
              id="cardNumber"
              label="Número de tarjeta"
              inputMode="numeric"
              autoComplete="cc-number"
              hint="16 dígitos, sin espacios."
              error={errors.cardNumber?.message}
              register={register('cardNumber', {
                required: 'Ingresa el número de tarjeta',
                pattern: {
                  value: /^\d{16}$/,
                  message: 'Debe tener 16 dígitos sin espacios',
                },
              })}
            />
            <Field
              id="cardExpiry"
              label="Vencimiento (MM/AA)"
              inputMode="numeric"
              autoComplete="cc-exp"
              error={errors.cardExpiry?.message}
              register={register('cardExpiry', {
                required: 'Ingresa el vencimiento',
                pattern: {
                  value: /^(0[1-9]|1[0-2])\/\d{2}$/,
                  message: 'Formato MM/AA',
                },
              })}
            />
            <Field
              id="cardCvv"
              label="CVV"
              inputMode="numeric"
              autoComplete="cc-csc"
              hint="3 dígitos al reverso de la tarjeta."
              error={errors.cardCvv?.message}
              register={register('cardCvv', {
                required: 'Ingresa el CVV',
                pattern: {
                  value: /^\d{3,4}$/,
                  message: '3 o 4 dígitos',
                },
              })}
            />
          </Row>
        </Section>

        <div className="flex justify-end gap-3 border-t border-zinc-200 pt-6">
          <button
            type="reset"
            className="rounded-lg border-2 border-zinc-300 px-5 py-2.5 text-sm font-semibold text-zinc-700 hover:bg-zinc-100"
          >
            Cancelar
          </button>
          <button
            type="submit"
            className="rounded-lg bg-purple-700 px-5 py-2.5 text-sm font-semibold text-white hover:bg-purple-800"
          >
            Confirmar compra
          </button>
        </div>
      </form>
    </>
  )
}

// ---------------------------------------------------------------------------
// Section uses semantic <fieldset>/<legend>
// ---------------------------------------------------------------------------
function Section({
  legend,
  children,
}: {
  legend: string
  children: React.ReactNode
}) {
  return (
    <fieldset className="rounded-xl border-2 border-zinc-200 bg-white p-5">
      <legend className="px-2 text-sm font-bold uppercase tracking-wider text-purple-700">
        {legend}
      </legend>
      <div className="space-y-4">{children}</div>
    </fieldset>
  )
}

function Row({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{children}</div>
  )
}

// ---------------------------------------------------------------------------
// Field — keeps id/hint/error wiring consistent
// ---------------------------------------------------------------------------
type FieldProps = {
  id: string
  label: string
  hint?: string
  error?: string
  type?: string
  inputMode?: 'numeric' | 'tel' | 'email' | 'text'
  autoComplete?: string
  register: ReturnType<ReturnType<typeof useForm<CheckoutData>>['register']>
}

function Field({
  id,
  label,
  hint,
  error,
  type = 'text',
  inputMode,
  autoComplete,
  register,
}: FieldProps) {
  const hintId = hint ? `${id}-hint` : undefined
  const errorId = error ? `${id}-error` : undefined
  const describedBy = [errorId, hintId].filter(Boolean).join(' ') || undefined

  return (
    <div>
      <label htmlFor={id} className="block text-sm font-semibold text-zinc-900">
        {label}
      </label>
      <input
        id={id}
        type={type}
        inputMode={inputMode}
        autoComplete={autoComplete}
        aria-invalid={error ? 'true' : 'false'}
        aria-describedby={describedBy}
        className={`mt-1 w-full rounded-md border-2 px-3 py-2 text-sm ${
          error
            ? 'border-rose-500 bg-rose-50'
            : 'border-zinc-300 bg-white focus:border-purple-600'
        }`}
        {...register}
      />
      {hint && (
        <p id={hintId} className="mt-1 text-xs text-zinc-500">
          {hint}
        </p>
      )}
      {error && (
        <p
          id={errorId}
          className="mt-1 flex items-center gap-1 text-xs font-semibold text-rose-700"
        >
          <span aria-hidden="true">⚠</span>
          {error}
        </p>
      )}
    </div>
  )
}
