'use client'

import { useState } from 'react'
import { PageHeader } from '../../components/PageHeader'

// Antipattern showcase: placeholders as labels, generic errors,
// no focus management, color-only feedback, fake button.
export default function BadFormPage() {
  const [submitted, setSubmitted] = useState(false)
  const [hasErrors, setHasErrors] = useState(false)

  return (
    <>
      <PageHeader
        title="Formulario inaccesible"
        description="Esta es la versión que ves todos los días. Mírala con teclado, mírala con VoiceOver — y mira cómo falla."
        takeaway="Lo que parece 'limpio y minimalista' suele ser una barrera para alguien."
      />

      <div className="grid gap-8 md:grid-cols-2">
        <form
          onSubmit={(e) => {
            e.preventDefault()
            const form = e.currentTarget as HTMLFormElement
            const email = (
              form.querySelector('[name="email"]') as HTMLInputElement
            ).value
            const password = (
              form.querySelector('[name="password"]') as HTMLInputElement
            ).value
            if (!email || !password || !email.includes('@')) {
              setHasErrors(true)
              setSubmitted(false)
            } else {
              setHasErrors(false)
              setSubmitted(true)
            }
          }}
          className="rounded-xl border-2 border-rose-200 bg-white p-6"
          // noValidate so the demo shows our (bad) error UI instead of the browser's
          noValidate
        >
          <h2 className="mb-4 font-bold text-rose-700">Login</h2>

          {/* No <label>. Placeholder doing label duty. */}
          <input
            type="text"
            name="email"
            placeholder="Tu email"
            className={`w-full border-b-2 border-zinc-300 px-1 py-2 text-sm placeholder:text-zinc-400 focus:border-rose-500 focus:outline-none ${
              hasErrors ? 'border-rose-500' : ''
            }`}
          />

          <input
            type="password"
            name="password"
            placeholder="Contraseña"
            className={`mt-4 w-full border-b-2 border-zinc-300 px-1 py-2 text-sm placeholder:text-zinc-400 focus:border-rose-500 focus:outline-none ${
              hasErrors ? 'border-rose-500' : ''
            }`}
          />

          {/* Generic error — vague, doesn't point to which field */}
          {hasErrors && (
            <p className="mt-4 text-sm text-rose-600">
              Error. Revisa el formulario.
            </p>
          )}
          {submitted && (
            <p className="mt-4 text-sm text-green-600">¡Enviado!</p>
          )}

          {/* A <div> styled as a button. Not focusable. Not announced. */}
          <div
            onClick={(e) => {
              const form = (e.currentTarget as HTMLDivElement).closest('form')
              form?.requestSubmit()
            }}
            className="mt-6 cursor-pointer rounded-lg bg-rose-600 px-4 py-2 text-center text-sm font-semibold text-white"
          >
            Entrar
          </div>
        </form>

        <aside aria-labelledby="bad-list" className="text-sm">
          <h2 id="bad-list" className="mb-3 font-bold text-zinc-900">
            ¿Qué hay de malo aquí?
          </h2>
          <ul className="space-y-3">
            <Item>
              <strong>Sin <code>&lt;label&gt;</code>:</strong> los placeholders desaparecen
              al tipear; los lectores de pantalla no los anuncian de forma
              confiable.
            </Item>
            <Item>
              <strong>Error genérico:</strong> "Error. Revisa el formulario." no
              dice <em>cuál</em> campo ni <em>cómo</em> arreglarlo.
            </Item>
            <Item>
              <strong>Solo color para el error:</strong> el borde rojo es invisible
              para personas con daltonismo o monitores en escala de grises.
            </Item>
            <Item>
              <strong>Botón falso:</strong> un <code>&lt;div onClick&gt;</code> no es
              enfocable con Tab, no responde a <kbd>Enter</kbd>/<kbd>Espacio</kbd>{' '}
              y se anuncia como "texto".
            </Item>
            <Item>
              <strong>Sin retorno de foco:</strong> al fallar, el usuario debe
              buscar manualmente dónde estaba.
            </Item>
            <Item>
              <strong>Sin <code>aria-live</code>:</strong> el error nunca se
              anuncia automáticamente al lector de pantalla.
            </Item>
          </ul>
        </aside>
      </div>
    </>
  )
}

function Item({ children }: { children: React.ReactNode }) {
  return (
    <li className="flex items-start gap-2">
      <span aria-hidden="true" className="text-rose-500">
        ✗
      </span>
      <span>{children}</span>
    </li>
  )
}
