import Link from 'next/link'

type Section = {
  href: string
  title: string
  description: string
  emoji: string
}

const SECTIONS: Section[] = [
  {
    href: '/forms/bad',
    title: 'Formulario inaccesible',
    description:
      'Placeholders como labels, errores genéricos, sin manejo de foco. El antipatrón típico.',
    emoji: '❌',
  },
  {
    href: '/forms/good',
    title: 'Formulario accesible',
    description:
      'Mismo formulario, pero con labels, ARIA, mensajes de error específicos y foco en el primer campo inválido. Construido con react-hook-form.',
    emoji: '✅',
  },
  {
    href: '/forms/checkout',
    title: 'Checkout (real-world)',
    description:
      'Formulario más largo con autocomplete, fieldset/legend, "mismo que envío" y validación on-blur. El estándar de e-commerce hecho bien.',
    emoji: '🛒',
  },
  {
    href: '/focus',
    title: 'Estados de foco',
    description:
      'Compara el outline por defecto vs. el estilo "Oreo" (negro + blanco) que funciona en cualquier fondo.',
    emoji: '🎯',
  },
  {
    href: '/keyboard',
    title: 'Navegación por teclado',
    description:
      'Recorre toda la interfaz con Tab. Incluye un modal con foco atrapado y retorno al disparador.',
    emoji: '⌨️',
  },
  {
    href: '/alt-text',
    title: 'Texto alternativo',
    description:
      'Comparación lado a lado: misma imagen con y sin <code>alt</code>. Y un ejercicio: ¿cuál es el mejor alt para cada caso?',
    emoji: '🖼️',
  },
  {
    href: '/contrast',
    title: 'Contraste de color',
    description:
      'Ejemplos pasando y fallando WCAG AA / AAA, con la razón calculada en vivo.',
    emoji: '🎨',
  },
]

export default function Home() {
  return (
    <>
      <header className="mb-10">
        <p className="text-sm font-semibold uppercase tracking-wider text-purple-700">
          Clase 17 · IIC2182
        </p>
        <h1 className="mt-2 text-4xl font-bold tracking-tight text-zinc-900">
          Accesibilidad Web — Demo
        </h1>
        <p className="mt-3 max-w-2xl text-zinc-700">
          Demos cortos que acompañan la clase. Cada página aísla un concepto y lo
          muestra en código real. La estrella del show son los formularios con{' '}
          <code className="rounded bg-zinc-100 px-1.5 py-0.5 text-sm">
            react-hook-form
          </code>
          .
        </p>
      </header>

      <section aria-labelledby="secciones-heading">
        <h2 id="secciones-heading" className="sr-only">
          Secciones del demo
        </h2>
        <ul className="grid gap-4 sm:grid-cols-2">
          {SECTIONS.map((s) => (
            <li key={s.href}>
              <Link
                href={s.href}
                className="group block h-full rounded-xl border-2 border-zinc-200 bg-white p-5 transition hover:border-purple-400 hover:shadow-md"
              >
                <div className="flex items-start gap-3">
                  <span className="text-2xl" aria-hidden="true">
                    {s.emoji}
                  </span>
                  <div>
                    <h3 className="font-bold text-zinc-900 group-hover:text-purple-700">
                      {s.title}
                    </h3>
                    <p
                      className="mt-1 text-sm text-zinc-600"
                      dangerouslySetInnerHTML={{ __html: s.description }}
                    />
                  </div>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-12 rounded-xl border-2 border-purple-200 bg-purple-50 p-6">
        <h2 className="text-lg font-bold text-purple-900">
          Cómo usar este demo en clase
        </h2>
        <ol className="mt-3 list-decimal space-y-1 pl-5 text-sm text-zinc-800">
          <li>
            Abre el inspector de accesibilidad de DevTools (Chrome → Elements →
            Accessibility).
          </li>
          <li>
            Suelta el mouse y navega solo con <kbd>Tab</kbd>,{' '}
            <kbd>Shift+Tab</kbd>, <kbd>Enter</kbd>, <kbd>Space</kbd>, y{' '}
            <kbd>Esc</kbd>.
          </li>
          <li>
            Activa VoiceOver (macOS: <kbd>Cmd+F5</kbd>) y escucha cómo se anuncia
            cada formulario.
          </li>
          <li>
            Compara siempre las versiones ❌ y ✅ para sentir la diferencia.
          </li>
        </ol>
      </section>
    </>
  )
}
