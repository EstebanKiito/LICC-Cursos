type Props = {
  title: string
  description?: string
  takeaway?: string
}

export function PageHeader({ title, description, takeaway }: Props) {
  return (
    <header className="mb-8">
      <h1 className="text-3xl font-bold text-zinc-900">{title}</h1>
      {description && <p className="mt-2 text-zinc-700">{description}</p>}
      {takeaway && (
        <aside
          className="mt-4 rounded-lg border-2 border-yellow-300 bg-yellow-50 p-4"
          aria-label="Punto clave"
        >
          <div className="flex items-start gap-2">
            <span aria-hidden="true" className="text-lg">
              💡
            </span>
            <p className="text-sm text-zinc-800">
              <strong>Idea clave: </strong>
              {takeaway}
            </p>
          </div>
        </aside>
      )}
    </header>
  )
}
