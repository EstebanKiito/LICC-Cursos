import Link from 'next/link'

const SECTIONS: { href: string; label: string }[] = [
  { href: '/', label: 'Inicio' },
  { href: '/forms/bad', label: 'Form ❌' },
  { href: '/forms/good', label: 'Form ✅' },
  { href: '/forms/checkout', label: 'Checkout' },
  { href: '/focus', label: 'Foco' },
  { href: '/keyboard', label: 'Teclado' },
  { href: '/alt-text', label: 'Alt text' },
  { href: '/contrast', label: 'Contraste' },
]

export function Nav() {
  return (
    <nav aria-label="Secciones del demo" className="border-b border-zinc-200 bg-white">
      <ul className="mx-auto flex max-w-5xl flex-wrap gap-1 px-4 py-3 text-sm">
        {SECTIONS.map((s) => (
          <li key={s.href}>
            <Link
              href={s.href}
              className="rounded-md px-3 py-1.5 font-medium text-zinc-700 hover:bg-zinc-100"
            >
              {s.label}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  )
}
