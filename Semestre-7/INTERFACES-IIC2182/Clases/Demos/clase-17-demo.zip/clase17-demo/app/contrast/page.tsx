'use client'

import { useMemo, useState } from 'react'
import { PageHeader } from '../components/PageHeader'

// WCAG relative luminance & contrast ratio (https://www.w3.org/TR/WCAG21/#dfn-contrast-ratio)
function hexToRgb(hex: string): [number, number, number] | null {
  const m = hex.replace('#', '').match(/^([0-9a-f]{6}|[0-9a-f]{3})$/i)
  if (!m) return null
  const h = m[0].length === 3 ? m[0].split('').map((c) => c + c).join('') : m[0]
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)]
}

function luminance([r, g, b]: [number, number, number]) {
  const a = [r, g, b].map((v) => {
    const c = v / 255
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4)
  })
  return 0.2126 * a[0] + 0.7152 * a[1] + 0.0722 * a[2]
}

function contrastRatio(fg: string, bg: string): number | null {
  const f = hexToRgb(fg)
  const b = hexToRgb(bg)
  if (!f || !b) return null
  const L1 = luminance(f)
  const L2 = luminance(b)
  const [hi, lo] = L1 > L2 ? [L1, L2] : [L2, L1]
  return (hi + 0.05) / (lo + 0.05)
}

const PRESETS: { fg: string; bg: string; label: string }[] = [
  { fg: '#cccccc', bg: '#ffffff', label: 'Gris claro sobre blanco' },
  { fg: '#767676', bg: '#ffffff', label: 'Gris medio sobre blanco' },
  { fg: '#1d1d1f', bg: '#ffffff', label: 'Casi negro sobre blanco' },
  { fg: '#ffffff', bg: '#7c3aed', label: 'Blanco sobre púrpura' },
  { fg: '#ffe066', bg: '#ffffff', label: 'Amarillo sobre blanco' },
  { fg: '#ffffff', bg: '#181818', label: 'Blanco sobre casi negro' },
]

export default function ContrastPage() {
  const [fg, setFg] = useState('#ffffff')
  const [bg, setBg] = useState('#7c3aed')

  const ratio = useMemo(() => contrastRatio(fg, bg), [fg, bg])
  const verdict = useMemo(() => evaluate(ratio), [ratio])

  return (
    <>
      <PageHeader
        title="Contraste de color"
        description="WCAG pide 4.5:1 para texto normal, 3:1 para texto grande y componentes. AAA pide 7:1."
        takeaway="El contraste no es matemática — es '¿alguien puede leer esto cuando entra el sol?'"
      />

      <section className="grid gap-6 md:grid-cols-[1fr_1.2fr]">
        <div>
          <h2 className="text-lg font-bold text-zinc-900">Probá colores</h2>
          <div className="mt-4 space-y-4">
            <ColorInput label="Texto" value={fg} onChange={setFg} />
            <ColorInput label="Fondo" value={bg} onChange={setBg} />
          </div>

          <div className="mt-6 rounded-xl border-2 border-zinc-200 bg-white p-4">
            <p className="text-xs uppercase tracking-wide text-zinc-500">
              Razón de contraste
            </p>
            <p className="mt-1 font-mono text-3xl font-bold">
              {ratio ? ratio.toFixed(2) : '—'}:1
            </p>
            <ul className="mt-3 space-y-1 text-sm">
              <Verdict label="Texto normal AA (4.5:1)" pass={!!ratio && ratio >= 4.5} />
              <Verdict label="Texto grande AA (3:1)" pass={!!ratio && ratio >= 3} />
              <Verdict label="Texto normal AAA (7:1)" pass={!!ratio && ratio >= 7} />
            </ul>
            <p className={`mt-3 text-sm font-semibold ${verdict.tone}`}>
              {verdict.text}
            </p>
          </div>
        </div>

        <div
          style={{ background: bg, color: fg }}
          className="flex flex-col justify-center rounded-xl border-2 border-zinc-200 p-8"
        >
          <p className="text-xs uppercase tracking-wider opacity-70">
            Vista previa
          </p>
          <h2 className="mt-2 text-3xl font-bold">¿Puedes leer esto?</h2>
          <p className="mt-3">
            Este es texto normal en tu combinación de colores. Si te cuesta
            leerlo en una pantalla brillante, imagina al sol o con baja visión.
          </p>
          <button
            style={{ background: fg, color: bg }}
            className="mt-5 rounded-md px-4 py-2 text-sm font-bold"
          >
            Botón de ejemplo
          </button>
        </div>
      </section>

      <section aria-labelledby="presets" className="mt-12">
        <h2 id="presets" className="text-lg font-bold text-zinc-900">
          Combinaciones comunes
        </h2>
        <p className="mt-1 text-sm text-zinc-600">
          Clic para cargarlas en el probador.
        </p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {PRESETS.map((p) => {
            const r = contrastRatio(p.fg, p.bg) ?? 0
            const v = evaluate(r)
            return (
              <button
                key={p.label}
                type="button"
                onClick={() => {
                  setFg(p.fg)
                  setBg(p.bg)
                }}
                className="overflow-hidden rounded-xl border-2 border-zinc-200 text-left hover:border-purple-400"
              >
                <div
                  style={{ background: p.bg, color: p.fg }}
                  className="p-4 text-sm font-semibold"
                >
                  Texto de ejemplo
                </div>
                <div className="bg-white p-3 text-xs">
                  <p className="font-semibold">{p.label}</p>
                  <p className={`mt-1 ${v.tone}`}>
                    {r.toFixed(2)}:1 — {v.short}
                  </p>
                </div>
              </button>
            )
          })}
        </div>
      </section>

      <section className="mt-12 rounded-xl border-2 border-rose-200 bg-rose-50 p-5">
        <h2 className="font-bold text-rose-900">Y recuerda: color ≠ solo color</h2>
        <p className="mt-1 text-sm text-zinc-800">
          Aunque tu contraste pase, no uses solo color para comunicar estado.
          Acompáñalo con texto, íconos o forma.
        </p>
      </section>
    </>
  )
}

function ColorInput({
  label,
  value,
  onChange,
}: {
  label: string
  value: string
  onChange: (v: string) => void
}) {
  return (
    <label className="flex items-center gap-3">
      <span className="w-16 text-sm font-semibold">{label}</span>
      <input
        type="color"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-9 w-12 cursor-pointer rounded border-2 border-zinc-300"
        aria-label={`${label} color picker`}
      />
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="flex-1 rounded-md border-2 border-zinc-300 px-2 py-1 font-mono text-sm"
        aria-label={`${label} hex value`}
      />
    </label>
  )
}

function Verdict({ label, pass }: { label: string; pass: boolean }) {
  return (
    <li className="flex items-center gap-2">
      <span aria-hidden="true" className={pass ? 'text-green-600' : 'text-rose-600'}>
        {pass ? '✓' : '✗'}
      </span>
      <span className="text-zinc-800">{label}</span>
      <span
        className={`ml-auto rounded-full px-2 py-0.5 text-xs font-bold ${
          pass ? 'bg-green-100 text-green-800' : 'bg-rose-100 text-rose-800'
        }`}
      >
        {pass ? 'Pasa' : 'Falla'}
      </span>
    </li>
  )
}

function evaluate(ratio: number | null): {
  text: string
  short: string
  tone: string
} {
  if (!ratio) return { text: 'Color inválido', short: '—', tone: 'text-zinc-500' }
  if (ratio >= 7)
    return {
      text: '🌟 Excelente — pasa AAA',
      short: 'AAA',
      tone: 'text-green-700',
    }
  if (ratio >= 4.5)
    return {
      text: '✅ Bien — pasa AA para texto normal',
      short: 'AA',
      tone: 'text-green-700',
    }
  if (ratio >= 3)
    return {
      text: '⚠ Solo pasa para texto grande o componentes',
      short: 'AA grande',
      tone: 'text-amber-700',
    }
  return {
    text: '❌ Falla — no usar para texto',
    short: 'FALLA',
    tone: 'text-rose-700',
  }
}
