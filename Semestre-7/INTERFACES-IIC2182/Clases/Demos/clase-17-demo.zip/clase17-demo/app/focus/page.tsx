'use client'

import { PageHeader } from '../components/PageHeader'

export default function FocusPage() {
  return (
    <>
      <PageHeader
        title="Estados de foco"
        description="El reflector del escenario. Sin él, la navegación con teclado se rompe."
        takeaway="Un buen :focus-visible se ve sobre cualquier fondo, claro u oscuro."
      />

      <section className="grid gap-6 md:grid-cols-2">
        <Card title="❌ Foco invisible" tone="rose">
          <p className="text-sm text-zinc-700">
            <code>outline: none</code> sin reemplazo. Borde sutil que se pierde
            con el fondo.
          </p>
          <div className="mt-4 flex flex-wrap gap-3">
            <button className="rounded-md bg-rose-600 px-4 py-2 text-sm font-semibold text-white focus:outline-none">
              Comprar
            </button>
            <button className="rounded-md border-2 border-zinc-300 px-4 py-2 text-sm font-semibold focus:outline-none">
              Cancelar
            </button>
          </div>
          <p className="mt-3 text-xs text-zinc-500">
            Probá: hacé Tab sobre estos. ¿Sabés cuál tiene foco?
          </p>
        </Card>

        <Card title="✅ Foco 'Oreo' (Erik Kroes)" tone="green">
          <p className="text-sm text-zinc-700">
            Outline negro grueso + box-shadow blanco. Funciona sobre cualquier
            fondo.
          </p>
          <div className="mt-4 flex flex-wrap gap-3">
            <button className="oreo rounded-md bg-green-700 px-4 py-2 text-sm font-semibold text-white">
              Comprar
            </button>
            <button className="oreo rounded-md border-2 border-zinc-300 px-4 py-2 text-sm font-semibold">
              Cancelar
            </button>
          </div>
          <p className="mt-3 text-xs text-zinc-500">
            Probá: hacé Tab sobre estos. Imposible perderlos.
          </p>
        </Card>
      </section>

      <section className="mt-10 rounded-xl border-2 border-zinc-900 bg-zinc-900 p-6 text-white">
        <h2 className="font-bold">Sobre fondo oscuro también</h2>
        <p className="mt-1 text-sm text-zinc-300">
          La doble línea (negro + halo blanco) sigue visible cuando el fondo es
          oscuro:
        </p>
        <div className="mt-4 flex flex-wrap gap-3">
          <button className="oreo rounded-md bg-purple-500 px-4 py-2 text-sm font-semibold text-white">
            Botón primario
          </button>
          <button className="oreo rounded-md border-2 border-white/40 px-4 py-2 text-sm font-semibold">
            Botón secundario
          </button>
          <a
            href="#"
            className="oreo rounded-md px-4 py-2 text-sm font-semibold underline"
          >
            Un enlace
          </a>
        </div>
      </section>

      <section className="mt-10">
        <h2 className="text-lg font-bold text-zinc-900">CSS recomendado</h2>
        <pre className="mt-3 overflow-x-auto rounded-lg bg-zinc-900 p-4 text-xs text-zinc-100">
          <code>{`:focus-visible {
  outline: 3px solid #000;
  outline-offset: 2px;
  box-shadow: 0 0 0 5px #fff;
  border-radius: 4px;
}`}</code>
        </pre>
        <p className="mt-2 text-xs text-zinc-600">
          Importante: usa <code>:focus-visible</code>, no <code>:focus</code>.
          Así el outline aparece solo con teclado, no al hacer click con mouse.
        </p>
      </section>

      <style>{`
        .oreo:focus-visible {
          outline: 3px solid #000;
          outline-offset: 2px;
          box-shadow: 0 0 0 5px #fff;
        }
      `}</style>
    </>
  )
}

function Card({
  title,
  tone,
  children,
}: {
  title: string
  tone: 'rose' | 'green'
  children: React.ReactNode
}) {
  const cls =
    tone === 'rose'
      ? 'border-rose-200 bg-rose-50'
      : 'border-green-200 bg-green-50'
  return (
    <div className={`rounded-xl border-2 p-5 ${cls}`}>
      <h2 className="mb-2 font-bold text-zinc-900">{title}</h2>
      {children}
    </div>
  )
}
