'use client'

import { useEffect, useRef, useState } from 'react'
import { PageHeader } from '../components/PageHeader'

export default function KeyboardPage() {
  return (
    <>
      <PageHeader
        title="Navegación por teclado"
        description="Suelta el mouse. Recorré toda esta página con Tab, Shift+Tab, Enter, Espacio y Esc."
        takeaway="Si tu sitio no funciona con teclado, no funciona para mucha gente."
      />

      <section aria-labelledby="play" className="mb-10">
        <h2 id="play" className="text-lg font-bold text-zinc-900">
          Playground
        </h2>
        <p className="mt-1 text-sm text-zinc-700">
          Tab por estos controles. Probá <kbd>Enter</kbd> y <kbd>Espacio</kbd>{' '}
          en cada uno y notá la diferencia.
        </p>

        <div className="mt-4 flex flex-wrap items-center gap-3 rounded-xl border-2 border-zinc-200 bg-white p-5">
          <a
            href="#order"
            className="rounded-md bg-sky-700 px-4 py-2 text-sm font-semibold text-white"
          >
            Enlace (sólo Enter)
          </a>
          <button className="rounded-md bg-amber-700 px-4 py-2 text-sm font-semibold text-white">
            Botón (Enter o Espacio)
          </button>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" className="h-4 w-4" />
            Checkbox (Espacio)
          </label>
          <select
            aria-label="Talla"
            className="rounded-md border-2 border-zinc-300 bg-white px-3 py-2 text-sm"
          >
            <option>Talla S (↑↓ para cambiar)</option>
            <option>Talla M</option>
            <option>Talla L</option>
          </select>
          <ModalDemo />
        </div>
      </section>

      <section aria-labelledby="order">
        <h2 id="order" className="text-lg font-bold text-zinc-900">
          Orden de foco
        </h2>
        <p className="mt-1 text-sm text-zinc-700">
          El orden del Tab debe seguir el orden visual. Mirá cómo este formulario
          enfoca de arriba abajo, izquierda a derecha.
        </p>

        <form className="mt-4 grid gap-3 rounded-xl border-2 border-zinc-200 bg-white p-5 sm:grid-cols-2">
          <FocusField label="1. Nombre" />
          <FocusField label="2. Apellido" />
          <FocusField label="3. Email" type="email" />
          <FocusField label="4. Teléfono" type="tel" />
          <div className="sm:col-span-2 flex justify-end gap-2">
            <button
              type="reset"
              className="rounded-md border-2 border-zinc-300 px-4 py-2 text-sm font-semibold"
            >
              5. Limpiar
            </button>
            <button
              type="button"
              className="rounded-md bg-green-700 px-4 py-2 text-sm font-semibold text-white"
            >
              6. Enviar
            </button>
          </div>
        </form>
      </section>
    </>
  )
}

function FocusField({
  label,
  type = 'text',
}: {
  label: string
  type?: string
}) {
  const id = label.replace(/[^a-z0-9]/gi, '-').toLowerCase()
  return (
    <div>
      <label htmlFor={id} className="block text-xs font-semibold text-zinc-700">
        {label}
      </label>
      <input
        id={id}
        type={type}
        className="mt-1 w-full rounded-md border-2 border-zinc-300 bg-white px-3 py-2 text-sm"
      />
    </div>
  )
}

// ---------------------------------------------------------------------------
// Modal demo with focus trap, Esc to close, and focus return to opener
// ---------------------------------------------------------------------------
function ModalDemo() {
  const [open, setOpen] = useState(false)
  const triggerRef = useRef<HTMLButtonElement | null>(null)
  const dialogRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    if (!open) return

    const previouslyFocused = document.activeElement as HTMLElement | null

    // Move focus into the modal
    const focusables = dialogRef.current?.querySelectorAll<HTMLElement>(
      'a, button, input, [tabindex]:not([tabindex="-1"])'
    )
    focusables?.[0]?.focus()

    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpen(false)
        return
      }
      if (e.key !== 'Tab' || !focusables || focusables.length === 0) return
      const first = focusables[0]
      const last = focusables[focusables.length - 1]
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault()
        last.focus()
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault()
        first.focus()
      }
    }

    document.addEventListener('keydown', handleKey)
    return () => {
      document.removeEventListener('keydown', handleKey)
      // Return focus to the trigger or to wherever we came from
      ;(previouslyFocused ?? triggerRef.current)?.focus()
    }
  }, [open])

  return (
    <>
      <button
        ref={triggerRef}
        onClick={() => setOpen(true)}
        className="rounded-md bg-purple-700 px-4 py-2 text-sm font-semibold text-white"
      >
        Abrir modal accesible
      </button>

      {open && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50"
          onClick={(e) => {
            if (e.target === e.currentTarget) setOpen(false)
          }}
        >
          <div
            ref={dialogRef}
            role="dialog"
            aria-modal="true"
            aria-labelledby="dialog-title"
            className="w-full max-w-md rounded-xl bg-white p-6 shadow-2xl"
          >
            <h2 id="dialog-title" className="text-lg font-bold text-zinc-900">
              Confirma tu acción
            </h2>
            <p className="mt-2 text-sm text-zinc-700">
              Tab queda atrapado dentro del diálogo. <kbd>Esc</kbd> lo cierra. Al
              cerrar, el foco vuelve al botón que lo abrió.
            </p>
            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="rounded-md border-2 border-zinc-300 px-4 py-1.5 text-sm font-semibold"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="rounded-md bg-purple-700 px-4 py-1.5 text-sm font-semibold text-white"
              >
                Confirmar
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
