# Clase 17 — Accesibilidad Web Demo

Demo interactivo de accesibilidad web para IIC2182 Clase 17, centrado en formularios accesibles con `react-hook-form`.

## Cómo correr

```bash
pnpm install
pnpm dev
```

Luego abrir http://localhost:3017

## Conceptos cubiertos

Cada página del demo es una sección autónoma:

| Ruta | Concepto |
|------|----------|
| `/forms/bad` | Antipatrón: placeholders como labels, errores genéricos, botón falso (`div`) |
| `/forms/good` | Mismo login, accesible. Labels, `aria-invalid`, `aria-describedby`, `role="alert"`, retorno de foco al primer error — todo con `react-hook-form` |
| `/forms/checkout` | Flujo real con `<fieldset>`/`<legend>`, `autocomplete`, "misma dirección de envío" y resumen de errores enlazado |
| `/focus` | Comparación foco invisible vs. estilo "Oreo" (Erik Kroes) sobre fondo claro y oscuro |
| `/keyboard` | Playground de teclado + modal con focus trap, `Esc` y retorno de foco al disparador |
| `/alt-text` | Las cuatro preguntas + ejercicio interactivo: ¿cuál es el mejor `alt`? |
| `/contrast` | Probador en vivo: razón de contraste WCAG y veredicto AA/AAA |

## Cómo demostrarlo en clase

1. **Suelta el mouse.** Recorré cada página con `Tab`, `Shift+Tab`, `Enter`, `Espacio` y `Esc`.
2. **Activá VoiceOver** (macOS: `Cmd+F5`) y escuchá cómo se anuncia el formulario ❌ vs ✅.
3. **Comparas siempre las dos versiones** para sentir la diferencia en el cuerpo, no solo en el código.
4. **Skip link**: hacé `Tab` apenas carga cualquier página. Aparece "Saltar al contenido principal" — abajo a la izquierda.

## Stack

- Next.js 15 (App Router) + React 19
- TypeScript estricto
- Tailwind CSS 3
- `react-hook-form` 7 para validación y manejo de foco

## Estructura

```
app/
├── layout.tsx          # Skip link + nav + main landmark
├── globals.css         # Foco "Oreo", reduced-motion, skip-link
├── components/         # Nav, PageHeader
├── page.tsx            # Índice de demos
├── forms/
│   ├── bad/            # Antipatrón
│   ├── good/           # react-hook-form accesible
│   └── checkout/       # Multi-fieldset real
├── focus/              # Estados de foco
├── keyboard/           # Navegación por teclado + modal
├── alt-text/           # Ejercicio interactivo
└── contrast/           # Probador WCAG
```
