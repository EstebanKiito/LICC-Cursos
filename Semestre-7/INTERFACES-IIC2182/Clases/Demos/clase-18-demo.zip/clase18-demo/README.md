# Clase 18 — Motion Design con Framer Motion

Demo interactivo de Framer Motion para IIC2182 Clase 18. Cada ruta aísla un concepto y lo muestra con **demo + código + nota de uso**.

## Cómo correr

```bash
pnpm install
pnpm dev
```

Luego abrir http://localhost:3018

## Conceptos cubiertos

| Ruta | Concepto |
|------|----------|
| `/01-basics` | El componente `motion`, props `initial` / `animate` / `transition`, repetición |
| `/02-variants` | Estados nombrados, propagación padre → hijos, orquestación |
| `/03-gestures` | `whileHover`, `whileTap`, `drag` con constraints y snapback |
| `/04-easing` | Las 10 easings principales, comparadas lado a lado en vivo |
| `/05-spring` | Física de resortes con sliders (stiffness, damping, mass) + presets |
| `/06-stagger` | `staggerChildren`, `delayChildren`, `when` — secuenciar hijos |
| `/07-layout` | La prop `layout` para auto-animar cambios de DOM y reorden |
| `/08-shared-layout` | `layoutId` para transiciones de elemento compartido (estilo iOS) |
| `/09-scroll` | `useScroll` + `useTransform` para animaciones atadas al scroll |
| `/10-presence` | `AnimatePresence` con `exit` para modales y toasts |
| `/11-accessibility` | `useReducedMotion`, motion con propósito, reglas vestibulares |
| `/principles` | Los 12 principios clásicos de Disney aplicados a UI |
| `/real-world` | Patrones de producción: tabs, accordion, drawer, like button |

## Cómo enseñar

1. **Recorrer en orden las secciones 01 a 11.** Cada una se construye sobre la anterior.
2. **Abrir el código en VS Code paralelo al browser**, no solo leer las cajas de código del demo. Modificá props en vivo y observá el cambio.
3. **Probar `/11-accessibility` con `Reduce Motion` activado** en el sistema operativo — es la única forma de internalizar la diferencia.
4. **Cerrar con `/principles` y `/real-world`** para conectar la teoría con patrones que los alumnos ven todos los días.

## Stack

- Next.js 15 (App Router) + React 19
- TypeScript estricto
- Tailwind CSS 3
- Framer Motion 11

## Estructura

```
app/
├── layout.tsx              # Nav sticky + scaffold
├── globals.css             # Tema dark
├── components/
│   ├── Nav.tsx             # Nav con active state
│   └── Concept.tsx         # <Concept> y <Demo> reutilizables
├── page.tsx                # Índice con cards animadas
├── 01-basics/              # motion + animate + transition
├── 02-variants/            # Variants y propagación
├── 03-gestures/            # whileHover/Tap/Drag
├── 04-easing/              # Comparador visual de easings
├── 05-spring/              # Sliders interactivos de física
├── 06-stagger/             # Secuenciar hijos
├── 07-layout/              # Auto-layout y reorden
├── 08-shared-layout/       # layoutId
├── 09-scroll/              # useScroll / useTransform
├── 10-presence/            # AnimatePresence
├── 11-accessibility/       # useReducedMotion
├── principles/             # 12 principios de Disney
└── real-world/             # Tabs, accordion, drawer, like
```
