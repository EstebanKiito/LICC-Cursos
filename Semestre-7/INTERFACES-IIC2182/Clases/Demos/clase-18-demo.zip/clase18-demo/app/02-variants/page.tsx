'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Concept, Demo } from '../components/Concept'

// Variants are named animation states. They de-clutter the JSX and they
// propagate from parent to child by default — meaning the parent can drive
// the entire tree by just changing its own `animate` prop.

const cardVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: { opacity: 1, y: 0, scale: 1 },
}

const containerVariants = {
  closed: { opacity: 0, scale: 0.96 },
  open: {
    opacity: 1,
    scale: 1,
    transition: { staggerChildren: 0.08, delayChildren: 0.1 },
  },
}

const itemVariants = {
  closed: { opacity: 0, x: -16 },
  open: { opacity: 1, x: 0 },
}

export default function VariantsPage() {
  const [open, setOpen] = useState(false)

  return (
    <Concept
      number="02"
      title="Variants: estados nombrados y reutilizables"
      description="En vez de animar valores sueltos, definís estados (hidden, visible, hover, etc.) y la animación elige uno. Los hijos heredan el estado del padre — un solo toggle, todo el árbol responde."
      whenToUse="Cuando tenés más de un valor a animar, cuando varios elementos comparten estados, o cuando querés que el padre orqueste a sus hijos."
    >
      <Demo
        title="Estados nombrados"
        code={`const cardVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: { opacity: 1, y: 0, scale: 1 },
}

<motion.div
  variants={cardVariants}
  initial="hidden"
  animate={visible ? 'visible' : 'hidden'}
/>`}
        notes={
          <p>
            <code>animate</code> pasa a aceptar el <em>nombre</em> del estado.
            Más legible que un objeto inline.
          </p>
        }
      >
        <div className="flex flex-col items-center gap-4">
          <motion.div
            variants={cardVariants}
            initial="hidden"
            animate={open ? 'visible' : 'hidden'}
            transition={{ duration: 0.4 }}
            className="rounded-xl border border-violet-500/40 bg-violet-500/10 px-6 py-4 text-violet-100"
          >
            Soy una tarjeta con variants.
          </motion.div>
          <button
            onClick={() => setOpen((v) => !v)}
            className="rounded-md bg-violet-600 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-700"
          >
            {open ? 'Ocultar' : 'Mostrar'}
          </button>
        </div>
      </Demo>

      <Demo
        title="Propagación a hijos (orquestación)"
        code={`const container = {
  closed: { opacity: 0 },
  open: {
    opacity: 1,
    transition: { staggerChildren: 0.08, delayChildren: 0.1 },
  },
}

const item = {
  closed: { opacity: 0, x: -16 },
  open: { opacity: 1, x: 0 },
}

<motion.ul variants={container} animate={open ? 'open' : 'closed'}>
  {items.map(i => <motion.li variants={item} key={i} />)}
</motion.ul>`}
        notes={
          <p>
            El padre solo cambia su <code>animate</code>. Los hijos heredan el
            nombre y eligen su propia versión de <em>open</em> / <em>closed</em>.
          </p>
        }
      >
        <motion.ul
          variants={containerVariants}
          initial="closed"
          animate={open ? 'open' : 'closed'}
          className="flex w-full max-w-xs flex-col gap-2"
        >
          {['Inbox', 'Enviados', 'Borradores', 'Spam', 'Papelera'].map((s) => (
            <motion.li
              key={s}
              variants={itemVariants}
              className="rounded-md border border-zinc-700 bg-zinc-800/60 px-3 py-2 text-sm text-zinc-200"
            >
              {s}
            </motion.li>
          ))}
        </motion.ul>
      </Demo>
    </Concept>
  )
}
