'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Concept } from '../components/Concept'

export default function SpringPage() {
  const [stiffness, setStiffness] = useState(200)
  const [damping, setDamping] = useState(15)
  const [mass, setMass] = useState(1)
  const [trigger, setTrigger] = useState(0)

  const PRESETS = [
    { name: 'Gentle', stiffness: 120, damping: 14, mass: 1 },
    { name: 'Wobbly', stiffness: 180, damping: 8, mass: 1 },
    { name: 'Snappy', stiffness: 600, damping: 30, mass: 1 },
    { name: 'Slow', stiffness: 50, damping: 14, mass: 1 },
    { name: 'Heavy', stiffness: 200, damping: 15, mass: 4 },
  ]

  return (
    <Concept
      number="05"
      title="Spring: física de resortes"
      description="En vez de definir cuánto dura, definís cómo se siente. Tres parámetros: stiffness (rigidez del resorte), damping (resistencia), mass (peso del objeto). El tiempo lo calcula la física."
      whenToUse="Para microinteracciones que se deben sentir 'naturales' — drags, toggles, hovers. Mucho mejor que duration + easing cuando la entrada del usuario no es predecible."
    >
      <section className="grid gap-6 lg:grid-cols-[1fr_1fr]">
        <div>
          <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-zinc-400">
            Demo en vivo
          </h2>
          <div className="flex min-h-[280px] flex-col items-center justify-center gap-6 rounded-xl border border-zinc-800 bg-zinc-900 p-8">
            <motion.div
              key={`${stiffness}-${damping}-${mass}-${trigger}`}
              initial={{ x: -120 }}
              animate={{ x: 0 }}
              transition={{ type: 'spring', stiffness, damping, mass }}
              className="h-20 w-20 rounded-xl bg-violet-500 shadow-lg"
            />
            <button
              onClick={() => setTrigger((v) => v + 1)}
              className="rounded-md bg-violet-600 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-700"
            >
              ▶ Disparar
            </button>
          </div>
        </div>

        <div>
          <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-zinc-400">
            Parámetros
          </h2>
          <div className="space-y-5 rounded-xl border border-zinc-800 bg-zinc-900 p-5 text-sm">
            <Slider
              label="stiffness"
              value={stiffness}
              min={20}
              max={800}
              onChange={setStiffness}
              hint="Qué tan 'duro' es el resorte. Más alto = más rápido."
            />
            <Slider
              label="damping"
              value={damping}
              min={0}
              max={40}
              onChange={setDamping}
              hint="Resistencia. 0 = oscila infinito. Alto = se asienta rápido."
            />
            <Slider
              label="mass"
              value={mass}
              min={0.1}
              max={10}
              step={0.1}
              onChange={setMass}
              hint="Peso. Más pesado = más lento, más inercia."
            />

            <div>
              <div className="mb-2 text-xs uppercase tracking-wider text-zinc-500">
                Presets
              </div>
              <div className="flex flex-wrap gap-2">
                {PRESETS.map((p) => (
                  <button
                    key={p.name}
                    onClick={() => {
                      setStiffness(p.stiffness)
                      setDamping(p.damping)
                      setMass(p.mass)
                      setTrigger((v) => v + 1)
                    }}
                    className="rounded-md border border-violet-500/40 bg-violet-500/10 px-3 py-1 text-xs font-semibold text-violet-200 hover:bg-violet-500/20"
                  >
                    {p.name}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-zinc-400">
          Código
        </h2>
        <pre className="overflow-x-auto rounded-xl border border-zinc-800 bg-zinc-950 p-4 text-xs text-zinc-200">
          <code>{`<motion.div
  initial={{ x: -120 }}
  animate={{ x: 0 }}
  transition={{
    type: 'spring',
    stiffness: ${stiffness},
    damping: ${damping},
    mass: ${mass},
  }}
/>`}</code>
        </pre>
      </section>

      <section className="rounded-xl border border-violet-500/30 bg-violet-500/10 p-5 text-sm text-violet-100">
        <strong className="text-violet-300">Tip:</strong> empezá con un preset y
        ajustá. Para drag/toggle, <em>Snappy</em> casi nunca falla. Para entradas
        de cards o tooltips, <em>Gentle</em>. <em>Wobbly</em> reservalo para
        animaciones de juguete — irrita en producción.
      </section>
    </Concept>
  )
}

function Slider({
  label,
  value,
  min,
  max,
  step = 1,
  hint,
  onChange,
}: {
  label: string
  value: number
  min: number
  max: number
  step?: number
  hint: string
  onChange: (v: number) => void
}) {
  return (
    <div>
      <div className="flex items-baseline justify-between">
        <label className="font-mono text-xs text-violet-300">{label}</label>
        <span className="font-mono text-xs text-zinc-300">{value}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="mt-1 w-full accent-violet-500"
      />
      <p className="mt-1 text-xs text-zinc-500">{hint}</p>
    </div>
  )
}
