"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Concept, Demo } from "../components/Concept";

export default function BasicsPage() {
  const [on, setOn] = useState(false);

  return (
    <Concept
      number="01"
      title="Basics: el componente motion"
      description="Cualquier elemento HTML puede convertirse en animable con motion.div, motion.button, motion.h1, etc. Las props clave: initial (estado inicial), animate (estado actual), transition (cómo llegar)."
      whenToUse="Siempre que necesites animar una sola propiedad o un grupo simple. Es el punto de partida de todo lo demás."
    >
      <Demo
        title="motion.div con animate"
        code={`<motion.div
  animate={{
    x: on ? 100 : 0,
    backgroundColor: on ? '#8b5cf6' : '#3b82f6',
    borderRadius: on ? '50%' : '12%',
  }}
  transition={{ duration: 0.5, ease: 'easeInOut' }}
/>`}
        notes={
          <p>
            <code>animate</code> es un objeto declarativo. Cambia un valor →
            Framer Motion calcula la interpolación.
          </p>
        }
      >
        <div className="flex flex-col items-center gap-6">
          <motion.div
            animate={{
              x: on ? 100 : 0,
              backgroundColor: on ? "#8b5cf6" : "#3b82f6",
              borderRadius: on ? "50%" : "12%",
            }}
            transition={{ duration: 0.5, ease: "easeInOut" }}
            className="h-20 w-20"
          />
          <button
            onClick={() => setOn((v) => !v)}
            className="rounded-md bg-violet-600 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-700"
          >
            Toggle
          </button>
        </div>
      </Demo>

      <Demo
        title="initial + animate (entrada)"
        code={`<motion.div
  initial={{ opacity: 0, y: 20 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ duration: 0.6 }}
/>`}
        notes={
          <p>
            Útil para entradas al mount. <code>initial</code> define dónde
            empieza, <code>animate</code> dónde llega.
          </p>
        }
      >
        <motion.div
          key={String(on)}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="rounded-lg border border-violet-500/40 bg-violet-500/10 px-6 py-4 text-violet-100"
        >
          Hola curso
        </motion.div>
      </Demo>

      <Demo
        title="transition: duration, delay, ease, repeat"
        code={`<motion.div
  animate={{ rotate: 360 }}
  transition={{
    duration: 2,
    repeat: Infinity,
    ease: 'linear',
  }}
/>`}
        notes={
          <p>
            <code>repeat: Infinity</code> + <code>ease: 'linear'</code> =
            spinner. <code>repeatType: 'reverse'</code> para ping-pong.
          </p>
        }
      >
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          className="h-16 w-16 rounded-full border-4 border-violet-500 border-t-transparent animate-spin"
        />
      </Demo>
    </Concept>
  );
}
