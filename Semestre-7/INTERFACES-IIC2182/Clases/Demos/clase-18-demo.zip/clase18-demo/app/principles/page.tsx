'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'

type Principle = {
  number: number
  name: string
  brief: string
  uiContext: string
}

const PRINCIPLES: Principle[] = [
  {
    number: 1,
    name: 'Squash & Stretch',
    brief: 'Los objetos se deforman al moverse. Da vida y peso.',
    uiContext: 'Botones que se "aplastan" al ser presionados, loaders que rebotan.',
  },
  {
    number: 2,
    name: 'Anticipación',
    brief: 'Pequeño movimiento opuesto antes de la acción principal.',
    uiContext: 'Un menú que retrocede un toque antes de desplegarse.',
  },
  {
    number: 3,
    name: 'Staging',
    brief: 'Una acción a la vez, sin competir por atención.',
    uiContext: 'Un solo hero element animado a la vez. Stagger en vez de simultaneidad.',
  },
  {
    number: 4,
    name: 'Straight ahead vs pose-to-pose',
    brief: 'Animar frame a frame vs definir keyposes.',
    uiContext: 'Variants = pose-to-pose. Keyframes = straight ahead.',
  },
  {
    number: 5,
    name: 'Follow through & overlap',
    brief: 'Las partes secundarias terminan después de la principal.',
    uiContext: 'Un modal entra, sus children entran 100ms después. Stagger es esto.',
  },
  {
    number: 6,
    name: 'Slow in / slow out',
    brief: 'Acelerar al inicio, frenar al final. La famosa easing.',
    uiContext: 'easeInOut. Casi nada en UI debería ser lineal.',
  },
  {
    number: 7,
    name: 'Arc',
    brief: 'El movimiento natural sigue arcos, no rectas.',
    uiContext: 'Un toast que aparece desde la esquina cae en curva, no en línea.',
  },
  {
    number: 8,
    name: 'Secondary action',
    brief: 'Detalles que refuerzan la acción principal.',
    uiContext: 'El botón cambia color al mismo tiempo que la card entra.',
  },
  {
    number: 9,
    name: 'Timing',
    brief: 'Duración correcta = personalidad correcta.',
    uiContext: '150-300ms microinteracciones. 400-600ms transiciones complejas. >800ms se siente lento.',
  },
  {
    number: 10,
    name: 'Exageración',
    brief: 'Sobrepasar lo real para enfatizar.',
    uiContext: 'Un check de éxito que rebota un poco más fuerte que lo "natural" celebra el momento.',
  },
  {
    number: 11,
    name: 'Solid drawing',
    brief: 'Estructura coherente — el objeto se ve sólido al moverse.',
    uiContext: 'Tu botón debe seguir pareciendo botón mientras anima. No se distorsiona en feos pixeles.',
  },
  {
    number: 12,
    name: 'Appeal',
    brief: 'Carácter, no perfección técnica.',
    uiContext: 'Una animación con identidad de marca > una "técnicamente correcta" pero genérica.',
  },
]

export default function PrinciplesPage() {
  const [run, setRun] = useState(0)

  return (
    <>
      <header className="mb-10">
        <p className="font-mono text-xs uppercase tracking-widest text-violet-400">
          Bonus
        </p>
        <h1 className="mt-1 text-3xl font-bold text-white">
          Los 12 principios de animación, aplicados a UI
        </h1>
        <p className="mt-2 max-w-2xl text-zinc-400">
          Los principios clásicos de Disney (1981) siguen siendo la base del
          buen motion design. Acá traducidos a contexto de interfaz.
        </p>
      </header>

      <section className="mb-10 rounded-xl border border-zinc-800 bg-zinc-900 p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-400">
            Mini demo: cinco principios en una animación
          </h2>
          <button
            onClick={() => setRun((v) => v + 1)}
            className="rounded-md bg-violet-600 px-4 py-1.5 text-sm font-semibold text-white hover:bg-violet-700"
          >
            ▶ Reproducir
          </button>
        </div>
        <div className="flex h-40 items-center justify-center">
          <motion.div
            key={run}
            initial={{ y: -8, scale: 1 }}
            animate={{
              y: [-8, 4, -120, 0],
              scale: [1, 1.1, 0.8, 1],
            }}
            transition={{
              duration: 1.2,
              times: [0, 0.15, 0.4, 1],
              ease: 'easeInOut',
            }}
            className="h-20 w-20 rounded-2xl bg-violet-500 shadow-xl shadow-violet-900/50"
          />
        </div>
        <p className="mt-3 text-xs text-zinc-400">
          <strong>Anticipación</strong> (cae un poco) →{' '}
          <strong>squash</strong> (se aplasta) → <strong>arc</strong> (sube en
          curva) → <strong>timing</strong> (mass + ease) →{' '}
          <strong>follow-through</strong> (rebota al aterrizar).
        </p>
      </section>

      <ul className="grid gap-3 sm:grid-cols-2">
        {PRINCIPLES.map((p) => (
          <li
            key={p.number}
            className="rounded-xl border border-zinc-800 bg-zinc-900 p-5"
          >
            <div className="flex items-baseline gap-3">
              <span className="font-mono text-xl font-bold text-violet-400">
                {p.number.toString().padStart(2, '0')}
              </span>
              <h3 className="text-base font-bold text-white">{p.name}</h3>
            </div>
            <p className="mt-2 text-sm text-zinc-300">{p.brief}</p>
            <p className="mt-2 text-xs text-violet-300">
              <strong>En UI:</strong> {p.uiContext}
            </p>
          </li>
        ))}
      </ul>
    </>
  )
}
