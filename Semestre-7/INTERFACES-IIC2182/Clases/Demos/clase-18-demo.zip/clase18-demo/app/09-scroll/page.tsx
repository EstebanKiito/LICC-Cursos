'use client'

import { useRef } from 'react'
import { motion, useScroll, useTransform, useSpring } from 'framer-motion'
import { Concept } from '../components/Concept'

export default function ScrollPage() {
  const containerRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({ container: containerRef })

  // Progress bar
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
  })

  // Parallax color
  const bg = useTransform(
    scrollYProgress,
    [0, 0.5, 1],
    ['#1e1b4b', '#6d28d9', '#ec4899']
  )

  // Rotation
  const rotate = useTransform(scrollYProgress, [0, 1], [0, 360])

  return (
    <Concept
      number="09"
      title="Scroll-tied: animar atado al scroll"
      description="useScroll devuelve un MotionValue de 0 a 1 que representa el progreso. useTransform lo mapea a cualquier valor visual: color, rotación, escala, posición, opacidad."
      whenToUse="Hero sections con parallax, indicadores de progreso, secciones que se revelan, efectos cinematográficos. Mucho más performante que useEffect + scrollY."
    >
      <section>
        <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-zinc-400">
          Demo (scrollá adentro del recuadro)
        </h2>
        <div
          ref={containerRef}
          className="relative h-96 overflow-y-auto rounded-xl border border-zinc-800"
        >
          {/* Progress bar fija arriba */}
          <motion.div
            style={{ scaleX, transformOrigin: 'left' }}
            className="sticky top-0 z-10 h-1 origin-left bg-violet-500"
          />

          <motion.div style={{ background: bg }} className="px-8 py-12">
            <div className="mb-12 flex items-center justify-between">
              <div>
                <h3 className="text-2xl font-bold text-white">Scrolleá ↓</h3>
                <p className="mt-1 text-sm text-white/70">
                  El color de fondo y la rotación dependen del scroll.
                </p>
              </div>
              <motion.div
                style={{ rotate }}
                className="h-16 w-16 rounded-xl bg-white shadow-2xl"
              />
            </div>

            {Array.from({ length: 8 }).map((_, i) => (
              <div
                key={i}
                className="mb-8 rounded-lg bg-white/10 p-6 text-white backdrop-blur"
              >
                <h4 className="text-lg font-bold">Sección {i + 1}</h4>
                <p className="mt-1 text-sm text-white/80">
                  Cada sección va revelando la siguiente. Notá cómo la barra
                  arriba se llena y el fondo cambia de color de a poco.
                </p>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      <section>
        <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-zinc-400">
          Código
        </h2>
        <pre className="overflow-x-auto rounded-xl border border-zinc-800 bg-zinc-950 p-4 text-xs text-zinc-200">
          <code>{`const containerRef = useRef(null)
const { scrollYProgress } = useScroll({ container: containerRef })

// MotionValue (0 → 1) mapeada a cualquier salida
const scaleX = useSpring(scrollYProgress, { stiffness: 100, damping: 30 })
const bg = useTransform(scrollYProgress, [0, 0.5, 1], ['#1e1b4b', '#6d28d9', '#ec4899'])
const rotate = useTransform(scrollYProgress, [0, 1], [0, 360])

// useSpring suaviza el valor — recomendable para progress bars
<motion.div style={{ scaleX, transformOrigin: 'left' }} />
<motion.div style={{ background: bg, rotate }} />`}</code>
        </pre>
      </section>

      <section className="rounded-xl border border-violet-500/30 bg-violet-500/10 p-5 text-sm text-violet-100">
        <strong className="text-violet-300">Tip de performance:</strong>{' '}
        <code className="text-violet-200">useTransform</code> y{' '}
        <code className="text-violet-200">MotionValue</code> no causan re-renders
        de React — actualizan el DOM directamente. Por eso es muy barato.
      </section>
    </Concept>
  )
}
