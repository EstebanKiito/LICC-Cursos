'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

const TABS = ['Overview', 'Stats', 'Reviews', 'Pricing']

export default function RealWorldPage() {
  return (
    <>
      <header className="mb-10">
        <p className="font-mono text-xs uppercase tracking-widest text-violet-400">
          Patrones
        </p>
        <h1 className="mt-1 text-3xl font-bold text-white">
          Patrones de producción
        </h1>
        <p className="mt-2 max-w-2xl text-zinc-400">
          Combinaciones de los conceptos vistos en componentes reales que
          encontrarás en cualquier app.
        </p>
      </header>

      <div className="grid gap-10 lg:grid-cols-2">
        <Pattern title="Tab indicator (shared layout)">
          <TabIndicator />
        </Pattern>
        <Pattern title="Accordion (layout)">
          <Accordion />
        </Pattern>
        <Pattern title="Drawer lateral (presence + spring)">
          <Drawer />
        </Pattern>
        <Pattern title="Like button (springy)">
          <LikeButton />
        </Pattern>
      </div>
    </>
  )
}

function Pattern({
  title,
  children,
}: {
  title: string
  children: React.ReactNode
}) {
  return (
    <section className="rounded-xl border border-zinc-800 bg-zinc-900 p-5">
      <h2 className="mb-4 text-sm font-bold uppercase tracking-wider text-zinc-400">
        {title}
      </h2>
      <div className="flex min-h-[200px] items-center justify-center">
        {children}
      </div>
    </section>
  )
}

// ---------------------------------------------------------------------------
// Tab indicator with layoutId — the underline slides between tabs
// ---------------------------------------------------------------------------
function TabIndicator() {
  const [active, setActive] = useState(TABS[0])

  return (
    <div className="w-full">
      <div className="flex gap-1 border-b border-zinc-700">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setActive(t)}
            className="relative px-4 py-2 text-sm font-semibold text-zinc-300 hover:text-white"
          >
            {t}
            {active === t && (
              <motion.div
                layoutId="tab-underline"
                className="absolute inset-x-0 -bottom-px h-0.5 bg-violet-500"
                transition={{ type: 'spring', stiffness: 400, damping: 30 }}
              />
            )}
          </button>
        ))}
      </div>
      <div className="mt-4 text-sm text-zinc-300">
        Contenido de <strong>{active}</strong>
      </div>
    </div>
  )
}

// ---------------------------------------------------------------------------
// Accordion using layout prop for auto-animating height
// ---------------------------------------------------------------------------
const FAQS = [
  { q: '¿Qué es Framer Motion?', a: 'Una librería declarativa de animación para React. Convierte cualquier elemento en animable mediante props.' },
  { q: '¿Reemplaza a CSS animations?', a: 'No siempre. Para microinteracciones simples, CSS sigue siendo válido. Para coordinación compleja, gestos y layout, Framer Motion gana.' },
  { q: '¿Pesa mucho?', a: 'La librería completa pesa ~30KB gzipped. Se puede tree-shake con la versión LazyMotion para casos críticos.' },
]

function Accordion() {
  const [openIdx, setOpenIdx] = useState<number | null>(0)

  return (
    <motion.ul layout className="w-full space-y-2">
      {FAQS.map((f, i) => {
        const open = openIdx === i
        return (
          <motion.li
            key={i}
            layout
            className="overflow-hidden rounded-lg border border-zinc-700 bg-zinc-800/60"
          >
            <button
              onClick={() => setOpenIdx(open ? null : i)}
              className="flex w-full items-center justify-between px-4 py-3 text-left text-sm font-semibold text-white"
              aria-expanded={open}
            >
              {f.q}
              <motion.span
                animate={{ rotate: open ? 180 : 0 }}
                className="text-violet-400"
              >
                ▾
              </motion.span>
            </button>
            <AnimatePresence initial={false}>
              {open && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.25, ease: 'easeOut' }}
                >
                  <p className="px-4 pb-3 text-sm text-zinc-300">{f.a}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.li>
        )
      })}
    </motion.ul>
  )
}

// ---------------------------------------------------------------------------
// Drawer with presence + spring + backdrop
// ---------------------------------------------------------------------------
function Drawer() {
  const [open, setOpen] = useState(false)

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="rounded-md bg-violet-600 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-700"
      >
        Abrir drawer
      </button>

      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
              className="fixed inset-0 z-50 bg-black/60"
            />
            <motion.aside
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="fixed right-0 top-0 z-50 h-full w-80 border-l border-zinc-700 bg-zinc-900 p-6"
            >
              <h3 className="text-lg font-bold text-white">Configuración</h3>
              <p className="mt-2 text-sm text-zinc-300">
                Un drawer típico: backdrop con fade, panel con spring lateral,
                exit que recoge todo al cerrar.
              </p>
              <button
                onClick={() => setOpen(false)}
                className="mt-6 rounded-md bg-violet-600 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-700"
              >
                Cerrar
              </button>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  )
}

// ---------------------------------------------------------------------------
// Like button: spring + key-to-replay
// ---------------------------------------------------------------------------
function LikeButton() {
  const [liked, setLiked] = useState(false)
  const [count, setCount] = useState(127)

  return (
    <button
      onClick={() => {
        setLiked((v) => !v)
        setCount((c) => c + (liked ? -1 : 1))
      }}
      className="flex items-center gap-2 rounded-full border border-zinc-700 bg-zinc-800 px-5 py-2.5 text-sm font-semibold text-white"
    >
      <motion.span
        key={String(liked)}
        initial={{ scale: liked ? 0.6 : 1 }}
        animate={{ scale: 1 }}
        transition={{ type: 'spring', stiffness: 500, damping: 12 }}
        className="text-xl"
      >
        {liked ? '❤️' : '🤍'}
      </motion.span>
      <motion.span
        key={count}
        initial={{ y: -10, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="tabular-nums"
      >
        {count}
      </motion.span>
    </button>
  )
}
