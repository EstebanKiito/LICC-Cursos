import type { Metadata } from 'next'
import './globals.css'
import { Nav } from './components/Nav'

export const metadata: Metadata = {
  title: 'Clase 18 — Motion Design con Framer Motion',
  description:
    'Demo interactivo de Framer Motion para IIC2182 — conceptos, gestos, layout, scroll y patrones reales',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es">
      <body>
        <Nav />
        <main className="mx-auto max-w-6xl px-4 py-10">{children}</main>
        <footer className="mt-16 border-t border-zinc-800 py-6 text-center text-xs text-zinc-500">
          IIC2182 — Clase 18 — Motion Design
        </footer>
      </body>
    </html>
  )
}
