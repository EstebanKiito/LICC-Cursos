'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Concept, Demo } from '../components/Concept'

type Toast = { id: number; text: string }

export default function PresencePage() {
  const [showModal, setShowModal] = useState(false)
  const [toasts, setToasts] = useState<Toast[]>([])

  const addToast = () => {
    const id = Date.now()
    setToasts((t) => [...t, { id, text: `Notificación #${id % 1000}` }])
    setTimeout(() => {
      setToasts((t) => t.filter((x) => x.id !== id))
    }, 3000)
  }

  return (
    <Concept
      number="10"
      title="AnimatePresence: animar la salida"
      description="React desmonta los componentes instantáneamente cuando cambian a null. AnimatePresence intercepta ese unmount y le da tiempo a una animación de salida (exit) antes de removerlo del DOM."
      whenToUse="Modales, drawers, dropdowns, toasts, tooltips, mensajes que aparecen y desaparecen, transiciones entre rutas."
    >
      <Demo
        title="Modal con entrada y salida"
        code={`<AnimatePresence>
  {open && (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}    // ← clave: define cómo sale
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.95, y: 10 }}
      />
    </motion.div>
  )}
</AnimatePresence>`}
        notes={
          <p>
            Sin <code>AnimatePresence</code>, el <code>exit</code> no funciona —
            React quita el elemento antes que pueda animarse.
          </p>
        }
      >
        <div className="flex flex-col items-center gap-4">
          <button
            onClick={() => setShowModal(true)}
            className="rounded-md bg-violet-600 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-700"
          >
            Abrir modal
          </button>

          <AnimatePresence>
            {showModal && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setShowModal(false)}
                className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
              >
                <motion.div
                  initial={{ scale: 0.9, y: 20, opacity: 0 }}
                  animate={{ scale: 1, y: 0, opacity: 1 }}
                  exit={{ scale: 0.95, y: 10, opacity: 0 }}
                  transition={{ type: 'spring', stiffness: 300, damping: 25 }}
                  onClick={(e) => e.stopPropagation()}
                  className="w-full max-w-sm rounded-xl border border-violet-500/40 bg-zinc-900 p-6"
                >
                  <h3 className="text-lg font-bold text-white">Modal con exit</h3>
                  <p className="mt-2 text-sm text-zinc-300">
                    Fijate cómo este modal hace fade-in con scale al aparecer y
                    fade-out con scale al cerrar. Tocá afuera o cerralo abajo.
                  </p>
                  <button
                    onClick={() => setShowModal(false)}
                    className="mt-5 w-full rounded-md bg-violet-600 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-700"
                  >
                    Cerrar
                  </button>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </Demo>

      <Demo
        title="Lista de toasts (mount/unmount múltiple)"
        code={`<AnimatePresence>
  {toasts.map(t => (
    <motion.div
      key={t.id}
      layout
      initial={{ opacity: 0, x: 200 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 200 }}
    />
  ))}
</AnimatePresence>`}
        notes={
          <p>
            Combinar <code>layout</code> + <code>AnimatePresence</code> permite
            que los toasts existentes se reacomoden cuando otro entra o sale.
          </p>
        }
      >
        <div className="flex w-full flex-col items-center gap-4">
          <button
            onClick={addToast}
            className="rounded-md bg-violet-600 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-700"
          >
            + Agregar toast
          </button>
          <ul className="flex w-full max-w-sm flex-col items-end gap-2">
            <AnimatePresence>
              {toasts.map((t) => (
                <motion.li
                  key={t.id}
                  layout
                  initial={{ opacity: 0, x: 100, scale: 0.9 }}
                  animate={{ opacity: 1, x: 0, scale: 1 }}
                  exit={{ opacity: 0, x: 100, scale: 0.9 }}
                  transition={{ type: 'spring', stiffness: 300, damping: 25 }}
                  className="w-full rounded-lg border border-violet-500/40 bg-violet-500/10 px-4 py-3 text-sm text-violet-100"
                >
                  {t.text}
                </motion.li>
              ))}
            </AnimatePresence>
          </ul>
        </div>
      </Demo>
    </Concept>
  )
}
