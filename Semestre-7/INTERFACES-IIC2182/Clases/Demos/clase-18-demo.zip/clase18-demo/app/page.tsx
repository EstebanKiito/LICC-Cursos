'use client'

import Link from 'next/link'
import { motion } from 'framer-motion'

type Section = {
  href: string
  number: string
  title: string
  description: string
}

const SECTIONS: Section[] = [
  {
    href: '/01-basics',
    number: '01',
    title: 'Basics',
    description:
      'El componente <motion>, props animate / initial / exit / transition.',
  },
  {
    href: '/02-variants',
    number: '02',
    title: 'Variants',
    description: 'Estados nombrados, reusables, propagables a hijos.',
  },
  {
    href: '/03-gestures',
    number: '03',
    title: 'Gestures',
    description: 'whileHover, whileTap, whileFocus, drag con constraints.',
  },
  {
    href: '/04-easing',
    number: '04',
    title: 'Easing',
    description:
      'Comparación visual de curvas: linear, easeIn, easeOut, anticipate, cubic-bezier.',
  },
  {
    href: '/05-spring',
    number: '05',
    title: 'Spring',
    description:
      'Física de resortes en vivo: stiffness, damping, mass — con sliders.',
  },
  {
    href: '/06-stagger',
    number: '06',
    title: 'Stagger',
    description:
      'Animar hijos en secuencia: staggerChildren, delayChildren, when.',
  },
  {
    href: '/07-layout',
    number: '07',
    title: 'Layout',
    description:
      'Auto-animar cambios de layout (reorden, resize, posición) con la prop layout.',
  },
  {
    href: '/08-shared-layout',
    number: '08',
    title: 'Shared layout',
    description:
      'layoutId: transiciones de elemento compartido entre rutas / vistas.',
  },
  {
    href: '/09-scroll',
    number: '09',
    title: 'Scroll-tied',
    description:
      'useScroll + useTransform para animaciones atadas al scroll del usuario.',
  },
  {
    href: '/10-presence',
    number: '10',
    title: 'AnimatePresence',
    description:
      'Animar mount/unmount con exit animations. Modales, listas, toasts.',
  },
  {
    href: '/11-accessibility',
    number: '11',
    title: 'Accesibilidad',
    description:
      'useReducedMotion, prefers-reduced-motion, y la regla "motion with purpose".',
  },
  {
    href: '/principles',
    number: '★',
    title: 'Los 12 principios',
    description:
      'Los principios clásicos de animación de Disney aplicados a UI.',
  },
  {
    href: '/real-world',
    number: '★',
    title: 'Patrones reales',
    description:
      'Modal, drawer, tab indicator, accordion, toast — todo armado.',
  },
]

export default function Home() {
  return (
    <>
      <motion.header
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        className="mb-12"
      >
        <p className="font-mono text-xs uppercase tracking-widest text-violet-400">
          Clase 18 · IIC2182
        </p>
        <h1 className="mt-2 text-5xl font-bold tracking-tight text-white">
          Motion Design con{' '}
          <span className="text-violet-400">Framer Motion</span>
        </h1>
        <p className="mt-4 max-w-2xl text-zinc-400">
          11 conceptos numerados + principios clásicos + patrones reales. Cada
          página aísla una idea y la muestra en código que podés copiar.
        </p>
      </motion.header>

      <section aria-labelledby="conceptos">
        <h2 id="conceptos" className="sr-only">
          Secciones del demo
        </h2>
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {SECTIONS.map((s, i) => (
            <motion.li
              key={s.href}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.4,
                delay: 0.05 + i * 0.04,
                ease: 'easeOut',
              }}
            >
              <Link
                href={s.href}
                className="group block h-full rounded-xl border border-zinc-800 bg-zinc-900 p-5 transition hover:border-violet-500 hover:bg-zinc-900/80"
              >
                <div className="flex items-baseline gap-3">
                  <span className="font-mono text-2xl font-bold text-violet-400">
                    {s.number}
                  </span>
                  <h3 className="text-lg font-bold text-white group-hover:text-violet-200">
                    {s.title}
                  </h3>
                </div>
                <p className="mt-2 text-sm text-zinc-400">{s.description}</p>
              </Link>
            </motion.li>
          ))}
        </ul>
      </section>

      <motion.section
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8, duration: 0.5 }}
        className="mt-12 rounded-xl border border-violet-500/30 bg-violet-500/10 p-6 text-sm"
      >
        <h2 className="font-bold text-violet-200">Cómo usar este demo</h2>
        <ol className="mt-3 list-decimal space-y-1 pl-5 text-zinc-300">
          <li>Recorrer en orden las secciones 01 a 11.</li>
          <li>
            Cada página tiene <strong>demo + código + nota de uso</strong>. Mira
            el demo, lee el código, lee la nota.
          </li>
          <li>
            Abrir DevTools y desactivar/modificar las props en vivo es la mejor
            forma de aprender.
          </li>
          <li>
            Una vez clara la base, las páginas de <em>Principios</em> y{' '}
            <em>Patrones reales</em> muestran cómo se combina todo.
          </li>
        </ol>
      </motion.section>
    </>
  )
}
