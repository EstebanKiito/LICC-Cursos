'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Concept } from '../components/Concept'

const EASINGS: { name: string; value: string | number[]; explain: string }[] = [
  { name: 'linear', value: 'linear', explain: 'Velocidad constante. Útil solo para spinners y loops mecánicos.' },
  { name: 'easeIn', value: 'easeIn', explain: 'Empieza lento, acelera. Sirve para salidas — el ojo "lo deja ir".' },
  { name: 'easeOut', value: 'easeOut', explain: 'Empieza rápido, frena. Estándar para entradas — el ojo "lo recibe".' },
  { name: 'easeInOut', value: 'easeInOut', explain: 'Suave en ambos extremos. La opción por defecto cuando dudás.' },
  { name: 'circIn', value: 'circIn', explain: 'Curva circular — entrada más dramática que easeIn.' },
  { name: 'circOut', value: 'circOut', explain: 'Frenado circular — más dramático que easeOut.' },
  { name: 'backIn', value: 'backIn', explain: 'Da un paso atrás antes de avanzar (anticipación).' },
  { name: 'backOut', value: 'backOut', explain: 'Pasa el destino y vuelve. Da sensación de "overshoot" o de tener peso.' },
  { name: 'anticipate', value: 'anticipate', explain: 'Anticipación clásica de Disney: pequeño retroceso, gran salto.' },
  { name: 'cubic-bezier', value: [0.6, 0.05, 0.1, 0.95], explain: 'Curva custom: [x1, y1, x2, y2]. Total control sobre la sensación.' },
]

export default function EasingPage() {
  const [run, setRun] = useState(0)

  return (
    <Concept
      number="04"
      title="Easing: la curva define la personalidad"
      description="La diferencia entre 'profesional' y 'amateur' suele ser la curva. Una animación con linear se siente mecánica; la misma con easeOut se siente intencional."
      whenToUse="Siempre. Cada animación tiene una easing — explícita o no. Cuando dudes, easeOut es la respuesta para entradas, easeIn para salidas."
    >
      <section className="rounded-xl border border-zinc-800 bg-zinc-900 p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-sm font-bold uppercase tracking-wider text-zinc-400">
            Compará todas a la vez
          </h2>
          <button
            onClick={() => setRun((v) => v + 1)}
            className="rounded-md bg-violet-600 px-4 py-1.5 text-sm font-semibold text-white hover:bg-violet-700"
          >
            ▶ Reproducir
          </button>
        </div>

        <div className="space-y-3">
          {EASINGS.map((e) => (
            <div key={e.name} className="grid grid-cols-[140px_1fr] items-center gap-4">
              <div>
                <div className="font-mono text-xs text-violet-300">{e.name}</div>
              </div>
              <div className="relative h-10 rounded-md bg-zinc-950">
                <motion.div
                  key={`${e.name}-${run}`}
                  initial={{ x: 0 }}
                  animate={{ x: 'calc(100% - 40px)' }}
                  transition={{ duration: 1.2, ease: e.value as any }}
                  className="absolute left-0 top-1 h-8 w-8 rounded-md bg-violet-500"
                />
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-zinc-400">
          Cuándo usar cada una
        </h2>
        <ul className="grid gap-2 text-sm">
          {EASINGS.map((e) => (
            <li
              key={e.name}
              className="rounded-md border border-zinc-800 bg-zinc-900 p-3"
            >
              <span className="font-mono text-violet-300">{e.name}</span>
              <span className="ml-3 text-zinc-300">{e.explain}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className="rounded-xl border border-violet-500/30 bg-violet-500/10 p-5 text-sm text-violet-100">
        <strong className="text-violet-300">Regla práctica:</strong> elementos
        que entran van con <code className="text-violet-200">easeOut</code> (el
        ojo "recibe"). Elementos que salen van con{' '}
        <code className="text-violet-200">easeIn</code> (el ojo "los deja ir").
        Movimientos que van y vuelven, <code className="text-violet-200">easeInOut</code>.
      </section>
    </Concept>
  )
}
