'use client'

import { useState } from 'react'
import { motion, useReducedMotion } from 'framer-motion'
import { Concept, Demo } from '../components/Concept'

export default function AccessibilityPage() {
  const prefersReducedMotion = useReducedMotion()
  const [show, setShow] = useState(false)

  return (
    <Concept
      number="11"
      title="Accesibilidad: motion con propósito"
      description="El movimiento puede ayudar a entender una interfaz — o puede causar náuseas, mareos y migrañas a personas con desórdenes vestibulares. Respetar prefers-reduced-motion no es opcional."
      whenToUse="Siempre. Toda animación grande, con parallax, rotación o desplazamiento rápido debería ofrecer una alternativa reducida."
    >
      <section className="rounded-xl border border-zinc-800 bg-zinc-900 p-5 text-sm">
        <p className="text-zinc-300">
          Tu sistema operativo reporta actualmente:{' '}
          {prefersReducedMotion ? (
            <strong className="text-emerald-400">
              prefers-reduced-motion: reduce ✓
            </strong>
          ) : (
            <strong className="text-amber-400">
              prefers-reduced-motion: no-preference
            </strong>
          )}
        </p>
        <p className="mt-2 text-xs text-zinc-500">
          En macOS: System Settings → Accessibility → Display → Reduce motion.
          En Windows: Settings → Accessibility → Visual effects → Animation
          effects. En iOS/Android: Settings → Accessibility → Motion.
        </p>
      </section>

      <Demo
        title="useReducedMotion: animación condicional"
        code={`const prefersReducedMotion = useReducedMotion()

<motion.div
  initial={{ x: prefersReducedMotion ? 0 : -200, opacity: 0 }}
  animate={{ x: 0, opacity: 1 }}
  transition={{ duration: prefersReducedMotion ? 0 : 0.6 }}
/>`}
        notes={
          <p>
            Si el usuario pidió reducir, dejá <strong>solo el fade</strong> (que
            es seguro). Eliminá los desplazamientos largos, los scales grandes,
            los rebotes.
          </p>
        }
      >
        <div className="flex flex-col items-center gap-4">
          <motion.div
            key={`${show}-${prefersReducedMotion}`}
            initial={{
              x: prefersReducedMotion ? 0 : -200,
              opacity: 0,
              scale: prefersReducedMotion ? 1 : 0.8,
            }}
            animate={{ x: 0, opacity: 1, scale: 1 }}
            transition={{
              duration: prefersReducedMotion ? 0 : 0.6,
              ease: 'easeOut',
            }}
            className="rounded-lg border border-violet-500/40 bg-violet-500/10 px-6 py-4 text-violet-100"
          >
            {prefersReducedMotion
              ? '✓ Animación reducida: solo fade-in.'
              : '⚡ Animación completa: slide + scale + fade.'}
          </motion.div>
          <button
            onClick={() => setShow((v) => !v)}
            className="rounded-md bg-violet-600 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-700"
          >
            Reproducir
          </button>
        </div>
      </Demo>

      <section>
        <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-zinc-400">
          Reglas para animación accesible
        </h2>
        <ul className="grid gap-2 text-sm">
          <Rule
            ok
            title="Motion con propósito"
            body="Cada animación debe ayudar al usuario a entender qué pasó (qué cambió, dónde, por qué). No 'decoración'."
          />
          <Rule
            ok
            title="Respetá prefers-reduced-motion"
            body="Usá useReducedMotion (Framer Motion) o @media (prefers-reduced-motion: reduce) en CSS. No lo ignores."
          />
          <Rule
            ok
            title="Fade y crossfade son seguros"
            body="Cambiar opacidad raramente causa problemas. Pueden quedarse incluso con reduced-motion."
          />
          <Rule
            warn
            title="Cuidado con scale grande"
            body="Saltos de scale > 1.2 o < 0.8 pueden marear. Limitalos o ofrecé alternativa."
          />
          <Rule
            warn
            title="Cuidado con rotaciones"
            body="Rotaciones de > 90° o continuas (loops) molestan a usuarios con desórdenes vestibulares."
          />
          <Rule
            bad
            title="No uses parallax sin opción de apagarlo"
            body="El parallax es uno de los efectos más reportados como causa de náuseas."
          />
          <Rule
            bad
            title="No animes 60+ elementos a la vez"
            body="Carga cognitiva. Stagger ≠ avalancha. Más de 7-9 elementos animando juntos satura."
          />
        </ul>
      </section>
    </Concept>
  )
}

function Rule({
  ok,
  warn,
  bad,
  title,
  body,
}: {
  ok?: boolean
  warn?: boolean
  bad?: boolean
  title: string
  body: string
}) {
  const tone = ok
    ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-100'
    : warn
      ? 'border-amber-500/30 bg-amber-500/10 text-amber-100'
      : 'border-rose-500/30 bg-rose-500/10 text-rose-100'
  const icon = ok ? '✓' : warn ? '⚠' : '✗'
  return (
    <li className={`flex items-start gap-3 rounded-lg border p-3 ${tone}`}>
      <span aria-hidden="true" className="text-lg leading-none">
        {icon}
      </span>
      <div>
        <strong className="block">{title}</strong>
        <p className="mt-0.5 text-xs opacity-80">{body}</p>
      </div>
    </li>
  )
}
