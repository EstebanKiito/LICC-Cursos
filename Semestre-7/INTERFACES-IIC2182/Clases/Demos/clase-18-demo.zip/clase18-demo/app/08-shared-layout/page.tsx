'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Concept, Demo } from '../components/Concept'

type Card = { id: string; emoji: string; title: string; body: string }

const CARDS: Card[] = [
  { id: 'a', emoji: '🌱', title: 'Plant', body: 'Una pequeña planta brotando en primavera.' },
  { id: 'b', emoji: '🐠', title: 'Fish', body: 'Un pez tropical en el arrecife.' },
  { id: 'c', emoji: '🦊', title: 'Fox', body: 'Un zorro astuto en el bosque.' },
  { id: 'd', emoji: '🌙', title: 'Moon', body: 'Una luna llena sobre el lago.' },
]

export default function SharedLayoutPage() {
  const [selected, setSelected] = useState<Card | null>(null)

  return (
    <Concept
      number="08"
      title="Shared layout: transiciones de elemento compartido"
      description="layoutId hace que dos elementos en distintas vistas se traten como el mismo. Framer Motion anima la posición, tamaño y estilo entre los dos — el efecto 'Material You' / iOS app transitions."
      whenToUse="Para enlazar cards de un grid con su detalle expandido, miniaturas con su imagen full-screen, items de lista con su edit panel."
    >
      <Demo
        title="Click en una card → se expande"
        code={`{/* Grid */}
{cards.map(c => (
  <motion.div
    key={c.id}
    layoutId={c.id}
    onClick={() => setSelected(c)}
  />
))}

{/* Detail (con AnimatePresence) */}
<AnimatePresence>
  {selected && (
    <motion.div
      layoutId={selected.id}
      onClick={() => setSelected(null)}
    >
      {/* el mismo elemento, expandido */}
    </motion.div>
  )}
</AnimatePresence>`}
        notes={
          <p>
            El <code>layoutId</code> debe ser idéntico en las dos posiciones.
            Funciona aún si los elementos no son adyacentes en el DOM.
          </p>
        }
      >
        <div className="relative w-full">
          <motion.ul className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {CARDS.map((c) => (
              <motion.li
                key={c.id}
                layoutId={c.id}
                onClick={() => setSelected(c)}
                className="flex aspect-square cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border border-zinc-700 bg-zinc-800/60 p-3 hover:border-violet-500"
              >
                <motion.span layout="position" className="text-3xl">
                  {c.emoji}
                </motion.span>
                <motion.span
                  layout="position"
                  className="text-xs font-semibold text-zinc-300"
                >
                  {c.title}
                </motion.span>
              </motion.li>
            ))}
          </motion.ul>

          <AnimatePresence>
            {selected && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setSelected(null)}
                className="absolute inset-0 z-10 flex items-center justify-center bg-black/70"
              >
                <motion.div
                  layoutId={selected.id}
                  className="flex w-full max-w-sm flex-col items-center gap-3 rounded-xl border border-violet-500/50 bg-zinc-900 p-8 text-center"
                  onClick={(e) => e.stopPropagation()}
                >
                  <motion.span layout="position" className="text-6xl">
                    {selected.emoji}
                  </motion.span>
                  <motion.h3
                    layout="position"
                    className="text-xl font-bold text-white"
                  >
                    {selected.title}
                  </motion.h3>
                  <motion.p
                    layout="position"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1, transition: { delay: 0.2 } }}
                    className="text-sm text-zinc-300"
                  >
                    {selected.body}
                  </motion.p>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </Demo>
    </Concept>
  )
}
