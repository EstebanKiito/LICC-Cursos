'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Concept, Demo } from '../components/Concept'

const container = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.08,
      delayChildren: 0.1,
      when: 'beforeChildren',
    },
  },
  exit: {
    opacity: 0,
    transition: {
      staggerChildren: 0.04,
      staggerDirection: -1,
      when: 'afterChildren',
    },
  },
}

const item = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -10 },
}

export default function StaggerPage() {
  const [show, setShow] = useState(true)

  return (
    <Concept
      number="06"
      title="Stagger: secuenciar hijos"
      description="Listas, menús, grids. Si todos los hijos aparecen a la vez, se siente caótico. Si aparecen en secuencia, se siente cinematográfico. Tres props clave: staggerChildren, delayChildren, when."
      whenToUse="Cualquier lista de 3+ elementos que aparece simultáneamente. Menús dropdown, items de notificación, cards de un grid en mount."
    >
      <Demo
        title="staggerChildren entre cada hijo"
        code={`const container = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.08,  // 80ms entre cada hijo
      delayChildren: 0.1,     // espera 100ms antes del primero
    },
  },
}

const item = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
}

<motion.ul variants={container} animate="visible">
  {items.map(i => <motion.li variants={item} />)}
</motion.ul>`}
        notes={
          <p>
            <code>staggerDirection: -1</code> invierte el orden (útil al cerrar
            un menú).
          </p>
        }
      >
        <div className="flex flex-col items-center gap-4">
          <motion.ul
            key={show ? 'on' : 'off'}
            variants={container}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-3 gap-2"
          >
            {Array.from({ length: 9 }).map((_, i) => (
              <motion.li
                key={i}
                variants={item}
                className="flex h-16 w-16 items-center justify-center rounded-lg bg-violet-500 text-sm font-bold text-white"
              >
                {i + 1}
              </motion.li>
            ))}
          </motion.ul>
          <button
            onClick={() => setShow((v) => !v)}
            className="rounded-md bg-violet-600 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-700"
          >
            ↻ Reproducir
          </button>
        </div>
      </Demo>

      <Demo
        title="when: 'beforeChildren' vs 'afterChildren'"
        code={`// beforeChildren: el padre termina, después los hijos
transition: { when: 'beforeChildren', staggerChildren: 0.1 }

// afterChildren: los hijos primero, después el padre
transition: { when: 'afterChildren' }`}
        notes={
          <p>
            Útil cuando el padre cambia tamaño o estructura: dejá que se asiente
            antes de que los hijos aparezcan, o que los hijos se vayan antes que
            el padre.
          </p>
        }
      >
        <p className="text-center text-sm text-zinc-400">
          Mirá el demo de arriba: el contenedor hace fade primero
          (<code>delayChildren: 0.1</code>) y después aparecen los items.
        </p>
      </Demo>
    </Concept>
  )
}
