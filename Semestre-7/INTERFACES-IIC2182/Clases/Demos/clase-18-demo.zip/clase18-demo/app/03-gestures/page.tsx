"use client";

import { useRef } from "react";
import { motion } from "framer-motion";
import { Concept, Demo } from "../components/Concept";

export default function GesturesPage() {
  const constraintsRef = useRef<HTMLDivElement>(null);

  return (
    <Concept
      number="03"
      title="Gestures: hover, tap, drag, focus"
      description="Framer Motion expone gestos del mouse/touch como props declarativas. whileHover / whileTap / whileFocus / whileDrag activan un estado mientras la interacción ocurre."
      whenToUse="Para microinteracciones (botones, cards, sliders). Reemplaza por completo CSS :hover / :active cuando la animación es compleja."
    >
      <Demo
        title="whileHover y whileTap"
        code={`<motion.button
  whileHover={{ scale: 1.05, y: -2 }}
  whileTap={{ scale: 0.95 }}
  transition={{ type: 'spring', stiffness: 400 }}
/>`}
        notes={
          <p>
            El <code>type: 'spring'</code> hace que la respuesta se sienta
            física, no programada. Probá hovear y soltar.
          </p>
        }
      >
        <motion.button
          whileHover={{ scale: 1.05, y: -2 }}
          whileTap={{ scale: 0.95 }}
          transition={{ type: "spring", stiffness: 1600, damping: 10 }}
          className="rounded-lg bg-violet-600 px-6 py-3 text-base font-semibold text-white shadow-lg shadow-violet-900/30"
        >
          Hovea o tocame
        </motion.button>
      </Demo>

      <Demo
        title="drag con constraints"
        code={`const constraintsRef = useRef(null)

<div ref={constraintsRef} className="relative h-40 w-full">
  <motion.div
    drag
    dragConstraints={constraintsRef}
    dragElastic={0.2}
    whileDrag={{ scale: 1.1 }}
  />
</div>`}
        notes={
          <p>
            <code>dragConstraints</code> con un <code>ref</code> limita el drag
            a esa caja. <code>dragElastic</code> permite "estirar" un poco más
            allá del borde.
          </p>
        }
      >
        <div
          ref={constraintsRef}
          className="relative h-48 w-full rounded-lg border-2 border-dashed border-zinc-700"
        >
          <motion.div
            drag
            dragConstraints={constraintsRef}
            dragElastic={0.2}
            whileDrag={{ scale: 1.1, cursor: "grabbing" }}
            whileHover={{ cursor: "grab" }}
            className="absolute left-1/2 top-1/2 h-16 w-16 -translate-x-1/2 -translate-y-1/2 rounded-xl bg-violet-500 shadow-lg"
          />
        </div>
      </Demo>

      <Demo
        title="drag con snapback (sin constraints)"
        code={`<motion.div
  drag="x"
  dragSnapToOrigin
  whileDrag={{ scale: 1.05 }}
/>`}
        notes={
          <p>
            <code>drag="x"</code> limita el eje. <code>dragSnapToOrigin</code>{" "}
            devuelve al origen al soltar — útil para swipe-to-action.
          </p>
        }
      >
        <motion.div
          drag="x"
          dragSnapToOrigin
          whileDrag={{ scale: 1.5 }}
          className="flex h-14 w-72 items-center justify-center rounded-full bg-violet-500 text-sm font-semibold text-white"
        >
          Arrastrame horizontal →
        </motion.div>
      </Demo>
    </Concept>
  );
}
