'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Concept, Demo } from '../components/Concept'

export default function LayoutPage() {
  const [expanded, setExpanded] = useState(false)
  const [items, setItems] = useState([1, 2, 3, 4])

  const shuffle = () => {
    setItems((prev) => [...prev].sort(() => Math.random() - 0.5))
  }

  return (
    <Concept
      number="07"
      title="Layout: auto-animar cambios de layout"
      description="La prop layout es magia: Framer Motion detecta cualquier cambio en la posición o tamaño del elemento (causado por CSS, JSX, reorden) y lo anima automáticamente."
      whenToUse="Cuando el cambio viene del DOM/CSS y no podés controlar las coordenadas a mano: reorden de listas, expandir/colapsar, cambios de grid, drag-and-drop."
    >
      <Demo
        title="layout: expandir / colapsar"
        code={`<motion.div
  layout
  onClick={() => setExpanded(v => !v)}
  className={expanded ? 'w-80 h-40' : 'w-40 h-20'}
/>`}
        notes={
          <p>
            Sin la prop <code>layout</code>, el cambio de tamaño es instantáneo.
            Con <code>layout</code>, Framer Motion lo interpola.
          </p>
        }
      >
        <motion.button
          layout
          onClick={() => setExpanded((v) => !v)}
          className={`flex items-center justify-center rounded-xl bg-violet-500 text-sm font-semibold text-white ${
            expanded ? 'h-32 w-80' : 'h-12 w-40'
          }`}
          transition={{ type: 'spring', stiffness: 250, damping: 25 }}
        >
          <motion.span layout="position">
            {expanded ? 'Tocá para colapsar' : 'Tocá para expandir'}
          </motion.span>
        </motion.button>
      </Demo>

      <Demo
        title="Reorden con layout"
        code={`{items.map(i => (
  <motion.div
    key={i}             // ← key estable es clave
    layout
    transition={{ type: 'spring', stiffness: 300, damping: 30 }}
  >
    {i}
  </motion.div>
))}`}
        notes={
          <p>
            La <code>key</code> tiene que ser estable (el id del item) para que
            Framer Motion sepa qué elemento es cuál y los anime al nuevo lugar.
          </p>
        }
      >
        <div className="flex flex-col items-center gap-4">
          <motion.ul
            layout
            className="flex w-72 flex-col gap-2"
          >
            {items.map((n) => (
              <motion.li
                key={n}
                layout
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                className="rounded-lg border border-violet-500/40 bg-violet-500/10 px-4 py-3 text-sm font-semibold text-violet-100"
              >
                Item #{n}
              </motion.li>
            ))}
          </motion.ul>
          <button
            onClick={shuffle}
            className="rounded-md bg-violet-600 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-700"
          >
            ⇅ Reordenar
          </button>
        </div>
      </Demo>
    </Concept>
  )
}
