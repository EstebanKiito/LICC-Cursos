'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'

const SECTIONS = [
  { href: '/', label: 'Inicio' },
  { href: '/01-basics', label: '01 · Basics' },
  { href: '/02-variants', label: '02 · Variants' },
  { href: '/03-gestures', label: '03 · Gestures' },
  { href: '/04-easing', label: '04 · Easing' },
  { href: '/05-spring', label: '05 · Spring' },
  { href: '/06-stagger', label: '06 · Stagger' },
  { href: '/07-layout', label: '07 · Layout' },
  { href: '/08-shared-layout', label: '08 · Shared' },
  { href: '/09-scroll', label: '09 · Scroll' },
  { href: '/10-presence', label: '10 · Presence' },
  { href: '/11-accessibility', label: '11 · A11Y' },
  { href: '/principles', label: 'Principios' },
  { href: '/real-world', label: 'Real-world' },
]

export function Nav() {
  const pathname = usePathname()
  return (
    <nav
      aria-label="Conceptos del demo"
      className="sticky top-0 z-40 border-b border-zinc-800 bg-zinc-950/80 backdrop-blur"
    >
      <ul className="no-scrollbar mx-auto flex max-w-6xl gap-1 overflow-x-auto px-4 py-3 text-xs">
        {SECTIONS.map((s) => {
          const active = pathname === s.href
          return (
            <li key={s.href} className="shrink-0">
              <Link
                href={s.href}
                className={`rounded-md px-3 py-1.5 font-medium transition ${
                  active
                    ? 'bg-violet-500 text-white'
                    : 'text-zinc-300 hover:bg-zinc-800'
                }`}
              >
                {s.label}
              </Link>
            </li>
          )
        })}
      </ul>
    </nav>
  )
}
