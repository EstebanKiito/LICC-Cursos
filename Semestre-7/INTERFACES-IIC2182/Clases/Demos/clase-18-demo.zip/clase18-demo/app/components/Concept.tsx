type Props = {
  number: string
  title: string
  description: string
  whenToUse?: string
  children: React.ReactNode
}

export function Concept({
  number,
  title,
  description,
  whenToUse,
  children,
}: Props) {
  return (
    <div>
      <header className="mb-8">
        <p className="font-mono text-xs uppercase tracking-widest text-violet-400">
          Concepto {number}
        </p>
        <h1 className="mt-1 text-3xl font-bold text-white">{title}</h1>
        <p className="mt-2 max-w-2xl text-zinc-400">{description}</p>
        {whenToUse && (
          <aside className="mt-4 rounded-lg border border-violet-500/30 bg-violet-500/10 p-3 text-sm text-violet-200">
            <strong className="text-violet-300">¿Cuándo usarlo?</strong>{' '}
            {whenToUse}
          </aside>
        )}
      </header>
      <div className="space-y-12">{children}</div>
    </div>
  )
}

export function Demo({
  title,
  children,
  code,
  notes,
}: {
  title: string
  children: React.ReactNode
  code: string
  notes?: React.ReactNode
}) {
  return (
    <section className="grid gap-4 lg:grid-cols-[1.1fr_1fr]">
      <div>
        <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-zinc-400">
          {title}
        </h2>
        <div className="flex min-h-[280px] items-center justify-center rounded-xl border border-zinc-800 bg-zinc-900 p-8">
          {children}
        </div>
        {notes && (
          <div className="mt-3 text-xs text-zinc-400">{notes}</div>
        )}
      </div>
      <div>
        <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-zinc-400">
          Código
        </h2>
        <pre className="overflow-x-auto rounded-xl border border-zinc-800 bg-zinc-950 p-4 text-xs leading-relaxed text-zinc-200">
          <code>{code}</code>
        </pre>
      </div>
    </section>
  )
}
